package programRunner;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

import allgui.customergui.CustomerRegistration;
import allgui.logingui.LoginPage;


public class MainApplicationStartup extends JFrame{
	
	
	public MainApplicationStartup(){ 
	
//	getContentPane().setBackground(SystemColor.BLACK);
//    setForeground(Color.WHITE);
    setSize(new Dimension(1000, 700));
    setDefaultCloseOperation(EXIT_ON_CLOSE);
    setLayout(null);
    setResizable(false);
    setIconImage(Toolkit.getDefaultToolkit().getImage(getClass().getResource("hotelicon1.png")));
    //To set the center
    Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
    setLocation(dim.width/2-getSize().width/2, dim.height/2-getSize().height/2);

    
    JPanel panel = new JPanel(){
        @Override
        public void paintComponent(Graphics g){
            super.paintComponent(g);
            try {
                ImageIcon img = new ImageIcon(this.getClass().getResource("homepage.png"));
                g.drawImage(img.getImage(), 0, 0, this.getWidth(), this.getWidth(), null);
            }catch (Exception e){
                e.printStackTrace();
            }
        }
    };
    panel.setBounds(0, -20, 1000, 700);
    panel.setLayout(null);
    panel.setBackground(SystemColor.BLACK);
    getContentPane().add(panel);
	
//	JPanel BtnPanel = new JPanel();
//	BtnPanel.setBounds(200,430,600,100);
//	BtnPanel.setBackground(new Color(204,255,153,10));
//	getContentPane().add(BtnPanel);
    
	
    JButton loginbtn = new JButton("Sign In");
    loginbtn.setBounds(300,450,150,50);
    loginbtn.setForeground(Color.WHITE);
    loginbtn.setBackground(Color.GREEN);
    loginbtn.setFocusable(false);
    loginbtn.setFont(new Font("Garamond", Font.BOLD, 25));
    add(loginbtn);
    loginbtn.addActionListener(new ActionListener() {
    	@Override
    	public void actionPerformed(ActionEvent e1) { 
   		new LoginPage();
    		dispose();
    	}
    });
    
    // Adding MouseListener to detect button hover
    loginbtn.addMouseListener(new MouseAdapter() {
        public void mouseEntered(MouseEvent e) {
        	loginbtn.setBackground(new Color(14,238,144)); // light green
        }
        public void mouseExited(MouseEvent e) {
        	loginbtn.setBackground(new Color(0,255,0)); // green
        }
    });
    
    
    JButton regbtn = new JButton("Sign Up");
    regbtn.setFocusable(false);
    regbtn.setBounds(550,450,150,50);
    regbtn.setForeground(Color.white);
    regbtn.setBackground(Color.BLUE);
    regbtn.setFont(new Font("Garamond", Font.BOLD, 25));
    add(regbtn);
    regbtn.addActionListener(new ActionListener() {
    	@Override
    	public void actionPerformed(ActionEvent e1) {
    		new CustomerRegistration();
    		dispose();
    	}
    });
    
   
    // Adding MouseListener to detect button hover
    regbtn.addMouseListener(new MouseAdapter() {
        public void mouseEntered(MouseEvent e) {
        	regbtn.setBackground(new Color(17,116,230)); // light blue
        }
        public void mouseExited(MouseEvent e) {
        	regbtn.setBackground(new Color(0,0,255)); // blue
        }
    });
    
	
	getContentPane().add(panel);
    setVisible(true);
	}	
	
	
	
	
 public static void main(String[] args) {
	 new MainApplicationStartup();
	}

}
