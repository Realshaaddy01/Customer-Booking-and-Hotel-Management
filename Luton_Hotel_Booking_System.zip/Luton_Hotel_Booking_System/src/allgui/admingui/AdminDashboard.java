package allgui.admingui;


import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.SystemColor;
import java.awt.Toolkit;
import java.awt.event.*;
import javax.swing.*;

import allgui.logingui.LoginPage;
import allgui.staffgui.ReceptionDashboard;
import allgui.staffgui.StaffRegistration;

public class AdminDashboard extends JFrame{

    private static final long serialVersionUID = 1L;

    public AdminDashboard() {
        // Setting the frame properties
        setTitle("Admin GUI");
        setSize(720, 500);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);
        
        Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
        setLocation(dim.width / 2 - getSize().width / 2, dim.height / 2 - getSize().height / 2);
        getContentPane().setLayout(null);
        
        JPanel Imgpanel = new JPanel(){
            @Override
            public void paintComponent(Graphics g){
                super.paintComponent(g);
                try {
                    ImageIcon img = new ImageIcon(this.getClass().getResource("adminpage.png"));
                    g.drawImage(img.getImage(), 0, 0, this.getWidth(), this.getWidth(), null);
                }catch (Exception e){
                    e.printStackTrace();
                }
            }
        };
        Imgpanel.setBounds(0, -20, 720, 500);
        Imgpanel.setLayout(null);
        Imgpanel.setBackground(SystemColor.BLACK);
        getContentPane().add(Imgpanel);

        
        JPanel btnpanel = new JPanel();
        btnpanel.setBounds(130, 200, 450, 200);
        btnpanel.setLayout(null);
        btnpanel.setBackground(new Color(0,0,0,50));
        Imgpanel.add(btnpanel);

        // Creating the buttons for the different operations
        JButton staffRegBtn = new JButton("Staff Registration");   
        staffRegBtn.setForeground(new Color(0,0,0));
        staffRegBtn.setBackground(new Color(196,255,230));
        staffRegBtn.setFont(new Font("Tahoma", Font.BOLD, 16));
        staffRegBtn.setBounds(140,30,180,40);
        btnpanel.add(staffRegBtn);
        
        staffRegBtn.addActionListener(new ActionListener() {
        	@Override
        	public void actionPerformed(ActionEvent e) {
        		new StaffRegistration();
        		dispose();
        	}
        });
        
        
        
        JButton masterBookingBtn = new JButton("Master Booking");
        masterBookingBtn.setForeground(new Color(0,0,0));
        masterBookingBtn.setBackground(new Color(176,190,250));
        masterBookingBtn.setFont(new Font("Tahoma", Font.BOLD, 16));
        masterBookingBtn.setBounds(140,150,180,35);
        btnpanel.add(masterBookingBtn);
        
        masterBookingBtn.addActionListener(new ActionListener() {
        	@Override
        	public void actionPerformed(ActionEvent e) {
        		new ReceptionDashboard();
        		dispose();
        	}
        });
        
        
        JButton LogOutBtn = new JButton("Logout");   
        LogOutBtn.setForeground(new Color(255,10,60));
        LogOutBtn.setBackground(new Color(255,255,230));
        LogOutBtn.setFont(new Font("Tahoma", Font.BOLD, 16));
        LogOutBtn.setBounds(300,445,120,35);
        Imgpanel.add(LogOutBtn);
        
        LogOutBtn.addActionListener(new ActionListener() {
        		@Override
        		public void actionPerformed(ActionEvent e) {
        			new LoginPage();
        			dispose();
        		}
        });
        
        
        setVisible(true);
    }

    public static void main(String[] args) {
        new AdminDashboard();
    }

}
