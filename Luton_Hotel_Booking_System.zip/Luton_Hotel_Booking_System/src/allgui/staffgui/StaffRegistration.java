package allgui.staffgui;


import javax.swing.*;

import DBControllers.DatabaseConnection;
import allgui.admingui.AdminDashboard;
import allgui.logingui.LoginPage;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class StaffRegistration extends JFrame {

    public StaffRegistration() {
        // Setting up the JFrame
        setTitle("Employee Registration Form");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(720, 720);
        setLocationRelativeTo(null);
        setResizable(false);
        
        
        JPanel Imgpanel = new JPanel(){
            @Override
            public void paintComponent(Graphics g){
                super.paintComponent(g);
                try {
                    ImageIcon img = new ImageIcon(this.getClass().getResource("staffreg.png"));
                    g.drawImage(img.getImage(), 0, 0, this.getWidth(), this.getWidth(), null);
                }catch (Exception e){
                    e.printStackTrace();
                }
            }
        };
        Imgpanel.setBounds(0, 0, 720, 620);
        Imgpanel.setLayout(null);
        Imgpanel.setBackground(SystemColor.BLACK);
        getContentPane().add(Imgpanel);
        
        
        JPanel headingpanel = new JPanel();
        headingpanel.setBounds(0,0,720,40);
        headingpanel.setBackground(new Color(50,60,250));
        Imgpanel.add(headingpanel);
 
        JLabel heading = new JLabel("Staff Registration Form");
        heading.setBounds(250,0,300,30);    
        heading.setForeground(new Color(255,255,255));
        heading.setFont(new Font("Garamond", Font.BOLD, 28));
        headingpanel.add(heading);
        
        JPanel Formpanel = new JPanel();
        Formpanel.setLayout(null);
        Formpanel.setBackground(new Color(180,240,190,10)); 
        Formpanel.setBounds(5,5,700,620);
        Formpanel.setLayout(null);
        Imgpanel.add(Formpanel);
        
        	

        // Creating the JLabel and JTextField for each field
        JLabel userRoleComboLabel = new JLabel("User Role:");
        userRoleComboLabel.setBounds(185,70,150,40);
        userRoleComboLabel.setForeground(new Color(155,25,255));
        userRoleComboLabel.setFont(new Font("Garamond", Font.BOLD, 20));
        Formpanel.add(userRoleComboLabel);
        
        String[] roles = {"Manager", "Receptionist", "Housekeeping", "Chef", "Waiter"};
        JComboBox<String> userRoleComboBox = new JComboBox<>(roles);
        userRoleComboBox.setForeground(new Color(25,100,255));
        userRoleComboBox.setBackground(new Color(204, 204, 255));  
        userRoleComboBox.setFont(new Font("Garamond", Font.BOLD, 18));
        userRoleComboBox.setBounds(350,70,170,35);
        Formpanel.add(userRoleComboBox);
      
        JLabel titlelbl = new JLabel("Title: ");
		titlelbl.setBounds(185, 130, 230, 25);
		titlelbl.setForeground(new Color(155,25,255));
		titlelbl.setFont(new Font("Verdana", Font.PLAIN, 20));
		Formpanel.add(titlelbl);
        
        String title1[] = { "Mr.", "Mrs.", "Miss." };
		JComboBox<String> titlebox = new JComboBox<>(title1);
		titlebox.setBackground(new Color(204, 204, 255));
		titlebox.setBounds(350, 130, 170, 25);
		titlebox.setFont(new Font("Verdana", Font.PLAIN, 20));
		Formpanel.add(titlebox);

        JLabel staffFullnameLabel = new JLabel("Staff Fullname:");
        staffFullnameLabel.setBounds(185,190,160,40);
        staffFullnameLabel.setForeground(new Color(155,25,255));
        staffFullnameLabel.setFont(new Font("Garamond", Font.BOLD, 20));
        Formpanel.add(staffFullnameLabel);

        JTextField staffFullnameTextField = new JTextField();
        staffFullnameTextField.setForeground(new Color(25,25,5));
        staffFullnameTextField.setBackground(new Color(204, 204, 255));
        staffFullnameTextField.setFont(new Font("Garamond", Font.BOLD, 18));
        staffFullnameTextField.setBounds(350,190,170,35);
        Formpanel.add(staffFullnameTextField);

        JLabel staffAddressLabel = new JLabel("Staff Address:");
        staffAddressLabel.setBounds(185,250,150,40);
        staffAddressLabel.setForeground(new Color(155,25,255));
        staffAddressLabel.setFont(new Font("Garamond", Font.BOLD, 20));
        Formpanel.add(staffAddressLabel);

        JTextField staffAddressTextField = new JTextField();
        staffAddressTextField.setForeground(new Color(25,25,5));
        staffAddressTextField.setBackground(new Color(204, 204, 255));
        staffAddressTextField.setFont(new Font("Garamond", Font.BOLD, 18));
        staffAddressTextField.setBounds(350,250,170,35);
        Formpanel.add(staffAddressTextField);

        JLabel staffEmailLabel = new JLabel("Staff Email:");
        staffEmailLabel.setBounds(185,310,150,40);
        staffEmailLabel.setForeground(new Color(155,25,255));
        staffEmailLabel.setFont(new Font("Garamond", Font.BOLD, 20));
        Formpanel.add(staffEmailLabel);

        JTextField staffEmailTextField = new JTextField();
        staffEmailTextField.setForeground(new Color(25,25,5));
        staffEmailTextField.setBackground(new Color(204, 204, 255));
        staffEmailTextField.setFont(new Font("Garamond", Font.BOLD, 18));
        staffEmailTextField.setBounds(350,310,170,35);
        Formpanel.add(staffEmailTextField);

        JLabel staffContactLabel = new JLabel("Staff Contact:");
        staffContactLabel.setBounds(185,370,150,40);
        staffContactLabel.setForeground(new Color(155,25,255));
        staffContactLabel.setFont(new Font("Garamond", Font.BOLD, 20));
        Formpanel.add(staffContactLabel);

        JTextField staffContactTextField = new JTextField();
        staffContactTextField.setForeground(new Color(25,25,5));
        staffContactTextField.setBackground(new Color(204, 204, 255));
        staffContactTextField.setFont(new Font("Garamond", Font.BOLD, 18));
        staffContactTextField.setBounds(350,370,170,35);
        Formpanel.add(staffContactTextField);

        JLabel usernameLabel = new JLabel("User Name:");
        usernameLabel.setBounds(185,430,150,40);
        usernameLabel.setForeground(new Color(155,25,255));
        usernameLabel.setFont(new Font("Garamond", Font.BOLD, 20));
        Formpanel.add(usernameLabel);
        
        JTextField usernameTextField = new JTextField();
        usernameTextField.setForeground(new Color(25,25,5));
        usernameTextField.setBackground(new Color(204, 204, 255));
        usernameTextField.setFont(new Font("Garamond", Font.BOLD, 18));
        usernameTextField.setBounds(350,430,170,35);
        Formpanel.add(usernameTextField);

        JLabel passwordLabel = new JLabel("Password:");
        passwordLabel.setBounds(185,490,150,40);
        passwordLabel.setForeground(new Color(155,25,255));
        passwordLabel.setFont(new Font("Garamond", Font.BOLD, 20));
        Formpanel.add(passwordLabel);
        
        JPasswordField passwordTextField = new JPasswordField();
        passwordTextField.setForeground(new Color(25,25,5));
        passwordTextField.setBackground(new Color(204, 204, 255));
        passwordTextField.setFont(new Font("Garamond", Font.BOLD, 18));
        passwordTextField.setBounds(350,490,170,35);
        Formpanel.add(passwordTextField);

        JButton Exitbtn = new JButton("Back");
        Exitbtn.setForeground(new Color(255,255,255));
        Exitbtn.setBackground(new Color(255,0,25));
        Exitbtn.setFont(new Font("Garamond", Font.BOLD, 20));
        Exitbtn.setBounds(150,580,150,40);
        Formpanel.add(Exitbtn);
      
        Exitbtn.addActionListener(new ActionListener() {
        	@Override
        	public void actionPerformed(ActionEvent e) {
        		dispose();
        		new AdminDashboard();
        	}
        });

        // Creating the JButton for submitting the form
        JButton submitButton = new JButton("Register");
        submitButton.setForeground(new Color(255,255,255));
        submitButton.setBackground(new Color(0,25,255));
        submitButton.setFont(new Font("Garamond", Font.BOLD, 20));
        submitButton.setBounds(360,580,150,40);
        Formpanel.add(submitButton);
      
        submitButton.addActionListener(new ActionListener() {
        	@Override
        	public void actionPerformed(ActionEvent e) {
        		  // convert to text
        	String	role = userRoleComboBox.getSelectedItem().toString();
        	String 	title = titlebox.getSelectedItem().toString();
        	String  name = staffFullnameTextField.getText().trim();
        	String  address = staffAddressTextField.getText().trim();
        	String  contact = staffContactTextField.getText(); 
        	String  email = staffEmailTextField.getText().trim();   
            String  userName = usernameTextField.getText().trim();
            String  password = String.valueOf(passwordTextField.getPassword()).trim();

                // Try- catch block
                try {
                    // To create connection object
                    Connection con = DatabaseConnection.connect();

                    // insert query to insert data in customer
                    String query = "insert into staffs(Title, Name, Address, Mobile, Email, Username, Password, Role ) values"
                            + "(?,?,?,?,?,?,?,?)";

                    //Create PreparedStatement
                    PreparedStatement pst = null;
                    pst = con.prepareStatement(query);

                    // Regex to check email validation
                    String emailRegex = "^[\\w-_\\.+]*[\\w-_\\.]\\@([\\w]+\\.)+[\\w]+[\\w]$";

                    // Regex to check password validation
                    String passwordRegex = "^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=])(?=\\S+$).{5,15}$";

                    // select query to display customer email
                    String queryEmail = "select * from staffs";
                    PreparedStatement pst2 = con.prepareStatement(queryEmail);
                    ResultSet rst = pst2.executeQuery();

                    String dataEmail = "";

                    while(rst.next()) {
                        dataEmail = rst.getString(8);
                    }

                    // Check some validation
                    if(name.length()==0 || address.length()==0 || contact.length()==0 ||
                            email.length()==0 || password.length()==0) {

                        JOptionPane.showMessageDialog(null, "All fields are  required to fill");
                    }
                    else if(email.equals(dataEmail)) {
                        JOptionPane.showMessageDialog(null, "Email already exist");
                    }
                    else if (!email.matches(emailRegex)) {
                        JOptionPane.showMessageDialog(null, "Email is not valid");
                    }
                    else if (!password.matches(passwordRegex)) {
                        JOptionPane.showMessageDialog(null, "Password must contain at least 5 character, one uppercase, one lowercase, one digit, one special character");
                    }
                    else {
                    	pst.setString(1, title);
                    	pst.setString(2, name);     
                        pst.setString(3, address);
                        pst.setString(4, contact);   
                        pst.setString(5, email);      
                        pst.setString(6, userName);
                        pst.setString(7, password);
                        pst.setString(8, role);

                        if (pst.executeUpdate() >0) {
                        	ImageIcon i = new ImageIcon(getClass().getResource("hotel icon.png"));
							JOptionPane.showMessageDialog(null, "Staff Registration Succesfull!!!","Luton Hotel System", JOptionPane.WIDTH, i);
                            new AdminDashboard();
                            dispose();
                        }
                    }
                }
                catch(Exception ex) {
                    JOptionPane.showMessageDialog(null, ex);
                }
            }
        });
        
        
        
    // Displaying the JFrame
    setVisible(true);
}

public static void main(String[] args) {
    new StaffRegistration();
	}
}