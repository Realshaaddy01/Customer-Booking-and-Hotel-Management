package allgui.staffgui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Frame;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSeparator;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.MatteBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;

import com.toedter.calendar.JDateChooser;

import allgui.billinggui.BillingPage;
import allgui.customergui.CustomerDetails;
import allgui.customergui.CustomerManagement;
import allModels.BookingModel1;
import allModels.BookingModel3;
import DBControllers.Globalfile;
import DBControllers.JDBCBooking;
import DBControllers.JDBCRoom;
import allModels.RoundPanelModel;
import allModels.RoomModel1;

import allgui.roomgui.RoomsList;
import allgui.roomgui.RoomMgmt;
import allgui.logingui.LoginPage;

public class ReceptionDashboard implements MouseListener {

	protected static final Color COLOR = null;

	JFrame frame;
	JPanel panel, center, north, south;
	JLabel startDate, checkOut, image, roomNo, days, titlelbl, payment, roomID, resultlbl, roomType, floor, title1,
			customerID, customerName, availableroomlbl, manageroomlbl, managecustomerlbl, manageservicesbl,
			managebillinglbl;

	JTextField roomtxt, roomIDTxt, CustomerNametxt, bookingsearch, bookingtxt, searchtxt;
	JComboBox daysCombo, roomTypeCombo, floorCombo, paymentMethodCombo;
	JButton check, checkbtn;
	TableRowSorter sorter;
	JTable table, table1;
	DefaultTableModel dtm, model;
	JTextField bookingidtxt, customeridtxt, roomidtxt;
	JDateChooser checkin, checkout1;
	JComboBox bookingtypetext;
	Object[] columnsName;
	ArrayList<BookingModel3> a5;

	public ReceptionDashboard() {

		// *******************Main Frame*********************
		frame = new JFrame();
		frame.setBackground(new Color(102, 204, 255));
		frame.setTitle("Luton Hotel Booking System");
		frame.setResizable(true);
		frame.setSize(1280, 720);
		frame.setLocationRelativeTo(null);
		frame.setIconImage(Toolkit.getDefaultToolkit().getImage(getClass().getResource("hotelicon1.png")));
		frame.setDefaultCloseOperation(frame.EXIT_ON_CLOSE);
		frame.setExtendedState(Frame.MAXIMIZED_BOTH);
		frame.getContentPane().setLayout(new BorderLayout());

		// -------------------North Panel--------------------
		JPanel HeadPanel = new JPanel();
		HeadPanel.setLayout(null);
		HeadPanel.setBackground(new Color(50, 60, 250));
		HeadPanel.setPreferredSize(new Dimension(100, 40));
		frame.add(HeadPanel, BorderLayout.NORTH);

		titlelbl = new JLabel("Reception Dashboard", SwingConstants.CENTER);
		titlelbl.setFont(new Font("Tahoma", Font.BOLD, 35));
		titlelbl.setForeground(Color.white);
		titlelbl.setBounds(480, 0, 450, 40);
		HeadPanel.add(titlelbl);

		JLabel welcomelbl = new JLabel("Welcome : ");
		welcomelbl.setFont(new Font("Times New Roman", Font.PLAIN, 18));
		welcomelbl.setForeground(Color.white);
		welcomelbl.setBounds(1150, 5, 150, 35);
		HeadPanel.add(welcomelbl);

		JLabel welcomelbl1 = new JLabel();
		welcomelbl1.setText(Globalfile.registrationUser.getUsername());
		welcomelbl1.setFont(new Font("Times New Roman", Font.PLAIN, 18));
		welcomelbl1.setForeground(Color.white);
		welcomelbl1.setBounds(1240, 5, 150, 35);
		HeadPanel.add(welcomelbl1);
		
		
		//---------------------Show Current Date------------------
		SimpleDateFormat dateformate=new SimpleDateFormat("yyyy-MM-dd");
		Date date=new Date();
		String currentDate=dateformate.format(date);
		

		// **************************Center Panel******************
		center = new JPanel();
		center.setLayout(new BorderLayout());
		frame.add(center, BorderLayout.CENTER);
		
		
		//------------North Panel Check-In TextField---------------------
		JTextField txtDate=new JTextField();
		txtDate.setEnabled(false);
		txtDate.setText(currentDate);
		txtDate.setBorder(new MatteBorder(0, 0, 0, 0, new Color(20,30,50)));
		txtDate.setForeground(Color.GRAY);
		txtDate.setFont(new Font("Tahoma",Font.BOLD,25));
		txtDate.setBounds(750,13,200,20);
		center.add(txtDate);

		// *********************Center North Panel******************
		JPanel OperationPanel = new JPanel();
		OperationPanel.setBackground(Color.white);
		OperationPanel.setLayout(null);
		OperationPanel.setPreferredSize(new Dimension(100, 440));
		center.add(OperationPanel, BorderLayout.NORTH);

		JLabel northTitle = new JLabel("SERVICES", SwingConstants.CENTER);
		northTitle.setFont(new Font("Tahoma", Font.BOLD, 30));
		northTitle.setBounds(235, 10, 450, 30);
		northTitle.setForeground(Color.BLACK);
		northTitle.setBackground(new Color(255,200,215));
		northTitle.setOpaque(true);
		OperationPanel.add(northTitle);

		// *****************Available Room Panel***************
		RoundPanelModel ManageRoomPanel = new RoundPanelModel();
		ManageRoomPanel.setRoundBottomRight(100);
		ManageRoomPanel.setRoundBottomLeft(100);
		ManageRoomPanel.setRoundTopLeft(100);
		ManageRoomPanel.setRoundTopRight(100);
		ManageRoomPanel.setLayout(null);
		ManageRoomPanel.setBackground(new Color(173,216,230));
		ManageRoomPanel.setBounds(40, 60, 220, 180);
		OperationPanel.add(ManageRoomPanel);

		// *******************Image for available room***************8
		JLabel img = new JLabel();
		img.setIcon(new javax.swing.ImageIcon(getClass().getResource("insidedesign-preview.png")));
		img.setBounds(35, 10, 128, 128);
		img.setFont(new Font("Tahoma", Font.BOLD, 18));
		img.setForeground(Color.white);
		ManageRoomPanel.add(img);

		// *******************Label for available room***************
		availableroomlbl = new JLabel("Manage Rooms");
		availableroomlbl.setForeground(new Color(0,0,205));
		availableroomlbl.setBounds(35, 130, 200, 30);
		availableroomlbl.setFont(new Font("Tahoma", Font.BOLD, 18));
		availableroomlbl.addMouseListener(this);
		ManageRoomPanel.add(availableroomlbl);
		availableroomlbl.addMouseListener(new MouseAdapter() {

			@Override
			public void mouseEntered(MouseEvent e) {

				availableroomlbl.setForeground(new Color(0,100,0));

			}

			@Override
			public void mouseExited(MouseEvent e) {

				availableroomlbl.setForeground(COLOR);
			}
			@Override
			public void mouseClicked(MouseEvent e) {
				new RoomMgmt();
			}

		});

		// *****************Customer Panel***************
		RoundPanelModel customerPanel = new RoundPanelModel();
		customerPanel.setRoundBottomRight(100);
		customerPanel.setRoundBottomLeft(100);
		customerPanel.setRoundTopLeft(100);
		customerPanel.setRoundTopRight(100);
		customerPanel.setLayout(null);
		customerPanel.setBackground(new Color(173,216,230));
		customerPanel.setBounds(330, 60, 220, 180);
		OperationPanel.add(customerPanel);

		// *******************Image for customer***************8
		JLabel img1 = new JLabel();
		img1.setIcon(new javax.swing.ImageIcon(getClass().getResource("rating-preview.png")));
		img1.setBounds(45, 10, 128, 128);
		img1.setFont(new Font("Tahoma", Font.BOLD, 18));
		img1.setForeground(Color.white);
		customerPanel.add(img1);

		// *******************Label for Customer Panel***************
		JLabel customerLabel = new JLabel("Manage Customer");
		customerLabel.setBounds(30, 130, 200, 30);
		customerLabel.setForeground(new Color(0,0,205));
		customerLabel.setFont(new Font("Tahoma", Font.BOLD, 18));
		customerLabel.addMouseListener(this);
		customerPanel.add(customerLabel);
		customerLabel.addMouseListener(new MouseAdapter() {

			@Override
			public void mouseEntered(MouseEvent e) {

				customerLabel.setForeground(new Color(0,100,0));

			}

			@Override
			public void mouseExited(MouseEvent e) {

				customerLabel.setForeground(COLOR);
			}

			@Override
			public void mouseClicked(MouseEvent e) {
					new CustomerManagement();
			}

		});

		// ***************** Customer Panel***************
		RoundPanelModel corporatePanel = new RoundPanelModel();
		corporatePanel.setRoundBottomRight(100);
		corporatePanel.setRoundBottomLeft(100);
		corporatePanel.setRoundTopLeft(100);
		corporatePanel.setRoundTopRight(100);
		corporatePanel.setLayout(null);
		corporatePanel.setBackground(new Color(173,216,230));
		corporatePanel.setBounds(620, 60, 220, 180);
		OperationPanel.add(corporatePanel);

		// *******************Image for  Customer***************8
		JLabel img2 = new JLabel();
		img2.setIcon(new javax.swing.ImageIcon(getClass().getResource("teamwork-preview.png")));
		img2.setBounds(35, 10, 128, 128);
		img2.setFont(new Font("Tahoma", Font.BOLD, 18));
		img2.setForeground(Color.white);
		corporatePanel.add(img2);

		// *******************Label for  Customer Panel***************
		JLabel corporateLabel = new JLabel("Search Customers");
		corporateLabel.setForeground(new Color(0,0,205));
		corporateLabel.setBounds(30, 130, 200, 30);
		corporateLabel.setFont(new Font("Tahoma", Font.BOLD, 18));
		corporateLabel.addMouseListener(this);
		corporatePanel.add(corporateLabel);
		corporateLabel.addMouseListener(new MouseAdapter() {

			@Override
			public void mouseEntered(MouseEvent e) {

				corporateLabel.setForeground(new Color(0,100,0));

			}

			@Override
			public void mouseExited(MouseEvent e) {

				corporateLabel.setForeground(COLOR);
			}

			@Override
			public void mouseClicked(MouseEvent e) {
					new CustomerDetails();
			}

		});

		// *****************Check Room Panel***************
		RoundPanelModel servicesPanel = new RoundPanelModel();
		servicesPanel.setRoundBottomRight(100);
		servicesPanel.setRoundBottomLeft(100);
		servicesPanel.setRoundTopLeft(100);
		servicesPanel.setRoundTopRight(100);
		servicesPanel.setLayout(null);
		servicesPanel.setBackground(new Color(173,216,230));
		servicesPanel.setBounds(620, 250, 220, 180);
		OperationPanel.add(servicesPanel);

		// *******************Image for Check Room***************8
		JLabel img3 = new JLabel();
		img3.setIcon(new javax.swing.ImageIcon(getClass().getResource("room-preview.png")));
		img3.setBounds(40, 10, 128, 128);
		img3.setFont(new Font("Tahoma", Font.BOLD, 18));
		img3.setForeground(Color.white);
		servicesPanel.add(img3);

		// *******************Label for Check Room Panel***************
		JLabel servicesLabel = new JLabel("Check Rooms");
		servicesLabel.setForeground(new Color(0,0,205));
		servicesLabel.setBounds(50, 130, 200, 30);
		servicesLabel.setFont(new Font("Tahoma", Font.BOLD, 18));
		servicesLabel.addMouseListener(this);
		servicesPanel.add(servicesLabel);
		servicesLabel.addMouseListener(new MouseAdapter() {

			@Override
			public void mouseEntered(MouseEvent e) {

				servicesLabel.setForeground(new Color(0,100,0));

			}

			@Override
			public void mouseExited(MouseEvent e) {

				servicesLabel.setForeground(COLOR);
			}

			@Override
			public void mouseClicked(MouseEvent e) {
				new RoomsList();
			}

		});
		
		
		
		// *****************Check-In Customer Panel***************
				RoundPanelModel checkPanel = new RoundPanelModel();
				checkPanel.setRoundBottomRight(100);
				checkPanel.setRoundBottomLeft(100);
				checkPanel.setRoundTopLeft(100);
				checkPanel.setRoundTopRight(100);
				checkPanel.setLayout(null);
				checkPanel.setBackground(new Color(173,216,230));
				checkPanel.setBounds(40, 250, 220, 180);
				OperationPanel.add(checkPanel);

				// *******************Image for Check-In Customer***************8
				JLabel img4 = new JLabel();
				img4.setIcon(new javax.swing.ImageIcon(getClass().getResource("checkin-preview.png")));
				img4.setBounds(40, 10, 128, 128);
				img4.setFont(new Font("Tahoma", Font.BOLD, 18));
				img4.setForeground(Color.white);
				checkPanel.add(img4);

				// *******************Label for Check-In Customer Panel***************
				JLabel checkLabel = new JLabel("Check-In");
				checkLabel.setForeground(new Color(0,0,205));
				checkLabel.setBounds(62, 135, 200, 30);
				checkLabel.setFont(new Font("Tahoma", Font.BOLD, 18));
				checkLabel.addMouseListener(this);
				checkPanel.add(checkLabel);
				checkLabel.addMouseListener(new MouseAdapter() {

					@Override
					public void mouseEntered(MouseEvent e) {

						checkLabel.setForeground(new Color(0,100,0));

					}

					@Override
					public void mouseExited(MouseEvent e) {

						checkLabel.setForeground(COLOR);
					}

					@Override
					public void mouseClicked(MouseEvent e) {
	             new CustomerCheckIn();
					}

				});
				
				
				// *****************Billing Customer Panel***************
				RoundPanelModel customerBillingPanel = new RoundPanelModel();
				customerBillingPanel.setRoundBottomRight(100);
				customerBillingPanel.setRoundBottomLeft(100);
				customerBillingPanel.setRoundTopLeft(100);
				customerBillingPanel.setRoundTopRight(100);
				customerBillingPanel.setLayout(null);
				customerBillingPanel.setBackground(new Color(173,216,230));
				customerBillingPanel.setBounds(330, 250, 220, 180);
				OperationPanel.add(customerBillingPanel);

				// *******************Image for Billing Customer***************8
				JLabel img5 = new JLabel();
				img5.setIcon(new javax.swing.ImageIcon(getClass().getResource("billing-preview.png")));
				img5.setBounds(40, 10, 128, 128);
				img5.setFont(new Font("Tahoma", Font.BOLD, 18));
				img5.setForeground(Color.white);
				customerBillingPanel.add(img5);

				// *******************Label for Billing Customer Panel***************
				JLabel customerBillingLabel = new JLabel("Billing");
				customerBillingLabel.setForeground(new Color(0,0,205));
				customerBillingLabel.setBounds(80, 135, 200, 30);
				customerBillingLabel.setFont(new Font("Tahoma", Font.BOLD, 18));
				customerBillingLabel.addMouseListener(this);
				customerBillingPanel.add(customerBillingLabel);
				customerBillingLabel.addMouseListener(new MouseAdapter() {

					@Override
					public void mouseEntered(MouseEvent e) {

						customerBillingLabel.setForeground(new Color(0,100,0));

					}

					@Override
					public void mouseExited(MouseEvent e) {

						customerBillingLabel.setForeground(COLOR);
					}

					@Override
					public void mouseClicked(MouseEvent e) {
	             new BillingPage();
					}

				});

		// ********************Center Booking Table*********************
		columnsName = new Object[8];
		columnsName[0] = "Customer ID";
		columnsName[1] = "Name";
		columnsName[2] = "Booking ID";
		columnsName[3] = "Check-In";
		columnsName[4] = "Check-Out";
		columnsName[5] = "Room ID";
		columnsName[6] = "Room Type";
		columnsName[7] = "Room Status";
		
		
		table1 = new JTable(model);

		model = (DefaultTableModel) table1.getModel();
		model.setColumnIdentifiers(columnsName);

		updateTable();
		
		JPanel tablePanel = new JPanel();
		tablePanel.setPreferredSize(new Dimension(915, 350));
		
		JScrollPane scroll1 = new JScrollPane(table1);	
		scroll1.add(new JPanel()); 
		scroll1.setPreferredSize(new Dimension(915, 250));
//		scroll1.setBounds(0,600,800,200);
		tablePanel.add(scroll1);
		
		JPanel emptyPanel = new JPanel();
		emptyPanel.setPreferredSize(new Dimension(200, 50));
		tablePanel.add(emptyPanel);
		center.add(tablePanel, BorderLayout.CENTER);

		

//--------------------West Panel----------------------------
		
		panel = new JPanel();
		panel.setBackground(new Color(173,216,230));
		panel.setLayout(null);
		panel.setBounds(0,0,450,720);
		panel.setPreferredSize(new Dimension(450, 100));
		frame.add(panel, BorderLayout.WEST);

		checkbtn = new JButton("Check Room");
		checkbtn.setFocusable(false);
		checkbtn.setFont(new Font("Verdana", Font.BOLD, 22));
		checkbtn.setBounds(80, 550, 280, 35);
		checkbtn.setForeground(Color.white);
		checkbtn.setBackground(new Color(50,25,255));
		panel.add(checkbtn);
		checkbtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				new RoomsList();

			}

		});
		
		JSeparator sep = new JSeparator();
		sep.setBounds(10, 565, 425, 21);
		panel.add(sep);

		title1 = new JLabel("CHECK FOR BOOKING", JLabel.CENTER);
		title1.setFont(new Font("Tahoma", Font.BOLD, 25));
		title1.setForeground(Color.BLACK);
		title1.setBounds(50, 20, 350, 35);
		panel.add(title1);

		JSeparator separator1 = new JSeparator();
		separator1.setBounds(10, 50, 420, 21);
		panel.add(separator1);
		
		JLabel logoImg = new JLabel();
		logoImg.setIcon(new javax.swing.ImageIcon(getClass().getResource("booking-preview.png")));
		logoImg.setBounds(160, 60, 128, 128);
		logoImg.setFont(new Font("Tahoma", Font.BOLD, 18));
		logoImg.setForeground(Color.BLACK);
		panel.add(logoImg);

		JLabel bookinglbl = new JLabel("Booking ID:");
		bookinglbl.setBounds(20, 200, 200, 35);
		bookinglbl.setFont(new Font("Verdana", Font.PLAIN, 18));
		bookinglbl.setForeground(Color.BLACK);
		panel.add(bookinglbl);

		bookingtxt = new JTextField();
		bookingtxt.setBorder(new MatteBorder(0, 0, 2, 0, Color.green));
		bookingtxt.setBounds(180, 200, 250, 35);
		bookingtxt.setFont(new Font("Verdana", Font.PLAIN, 18));
		panel.add(bookingtxt);

		JLabel CheckInlbl = new JLabel("Arrival Date:");
		CheckInlbl.setBounds(20, 250, 200, 35);
		CheckInlbl.setFont(new Font("Verdana", Font.PLAIN, 18));
		CheckInlbl.setForeground(Color.BLACK);
		panel.add(CheckInlbl);

		checkin = new JDateChooser();
		checkin.setBorder(new MatteBorder(0, 0, 2, 0, Color.green));
		checkin.setDateFormatString("yyyy-MM-dd");
		checkin.setBounds(180, 250, 250, 35);
		checkin.setFont(new Font("Verdana", Font.PLAIN, 18));
		panel.add(checkin);

		JLabel CheckOutlbl = new JLabel("Departure Date:");
		CheckOutlbl.setBounds(20, 300, 200, 35);
		CheckOutlbl.setFont(new Font("Verdana", Font.PLAIN, 18));
		CheckOutlbl.setForeground(Color.BLACK);
		panel.add(CheckOutlbl);

		checkout1 = new JDateChooser();
		checkout1.setDateFormatString("yyyy-MM-dd");
		checkout1.setBounds(180, 300, 250, 35);
		checkout1.setBorder(new MatteBorder(0, 0, 2, 0, Color.green));
		checkout1.setFont(new Font("Verdana", Font.PLAIN, 18));
		panel.add(checkout1);

		JLabel roomidlbl = new JLabel("Room No:");
		roomidlbl.setBounds(20, 350, 200, 35);
		roomidlbl.setFont(new Font("Verdana", Font.PLAIN, 18));
		roomidlbl.setForeground(Color.BLACK);
		panel.add(roomidlbl);

		roomidtxt = new JTextField();
		roomidtxt.setBounds(180, 350, 250, 35);
		roomidtxt.setBorder(new MatteBorder(0, 0, 2, 0, Color.green));
		roomidtxt.setFont(new Font("Verdana", Font.PLAIN, 18));
		panel.add(roomidtxt);

		JLabel statuslbl = new JLabel("Status:");
		statuslbl.setBounds(20, 400, 200, 35);
		statuslbl.setFont(new Font("Verdana", Font.PLAIN, 18));
		statuslbl.setForeground(Color.BLACK);
		panel.add(statuslbl);

		Object[] h5 = { "Booked", "Room Not Available" };
		bookingtypetext = new JComboBox(h5);
		bookingtypetext.setBounds(180, 400, 250, 35);
		bookingtypetext.setBorder(new MatteBorder(0, 0, 2, 0, Color.green));
		bookingtypetext.setFont(new Font("Verdana", Font.PLAIN, 18));
		panel.add(bookingtypetext);

		

		check = new JButton("Confirm Booking");
		check.setFocusable(false);
		check.setFont(new Font("Tahoma", Font.BOLD, 20));
		check.setForeground(Color.WHITE);
		check.setBackground(new Color(25,160,20));
		check.setBounds(120, 480, 210, 35);
		panel.add(check);
		check.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				// *********Update Room Status***************
				RoomModel1 room = new RoomModel1();

				int room_id1 = Integer.parseInt(roomidtxt.getText());

				room.setId(room_id1);
				room.setStatus("Booked");
				JDBCRoom jdbc1 = new JDBCRoom();
				boolean result1 = jdbc1.update1(room);

				// **************Update Customer Booking***********************
				int cusid = Integer.parseInt(bookingtxt.getText());
				String str1 = ((JTextField) checkin.getDateEditor().getUiComponent()).getText();
				String str2 = ((JTextField) checkout1.getDateEditor().getUiComponent()).getText();

				String bookingtype1 = bookingtypetext.getSelectedItem().toString();
				int room_id = Integer.parseInt(roomidtxt.getText());

				BookingModel1 booking = new BookingModel1();

				booking.setBooking_ID(cusid);
				booking.setCheckIn(str1);
				booking.setCheckOut(str2);
				booking.setRoom_ID(room_id);
				booking.setBooking_Status(bookingtype1);

				JDBCBooking jdbc = new JDBCBooking();
				boolean result = jdbc.update(booking);

				if (result == true) {
					updateTable();
					ImageIcon i = new ImageIcon(getClass().getResource("hotel icon.png"));
					JOptionPane.showMessageDialog(null, "The booking is done successfully", "Room Booking", JOptionPane.WIDTH, i);
				}

			}

		});
		
		JSeparator separator = new JSeparator();
		separator.setBounds(10, 497, 425, 21);
		panel.add(separator);


		

		JMenuItem LogOut = new JMenuItem("Log Out", JLabel.CENTER);
		LogOut.setBounds(20,2,80,40);
		LogOut.setBackground(new Color(255,50,20));
		LogOut.setFont(new Font("SansSerif", Font.BOLD, 18));
		LogOut.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent ae) {
				if (ae.getSource() == LogOut) {
					frame.dispose();
					new LoginPage();
				}
			}
		});
		HeadPanel.add(LogOut);

		JMenuItem Exit = new JMenuItem("Exit",JLabel.CENTER);
		Exit.setBounds(190,610,50,40);
		Exit.setBackground(COLOR.RED);
		Exit.setForeground(Color.white);
		Exit.setFont(new Font("SansSerif", Font.BOLD, 18));
		Exit.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent ae) {
				if (ae.getSource() == Exit) {
					System.exit(0);
				}
			}
		});
		panel.add(Exit);

	
		

		

		frame.setVisible(true);

	}

	public void updateTable() {

		a5 = new JDBCBooking().ReceptionViewAllCustomer();
		model.setRowCount(0);
		for (BookingModel3 bookingLibs : a5) {
			Object tmpRow[] = { bookingLibs.getCustomer_ID(), bookingLibs.getName(), bookingLibs.getBooking_ID(),
					bookingLibs.getCheckIn(), bookingLibs.getCheckOut(), bookingLibs.getRoom_ID(),
					bookingLibs.getBooking_Type(), bookingLibs.getBooking_Status()

			};

			model.addRow(tmpRow);
		}

		table1 = new JTable(model);
		JTableHeader t2 = table1.getTableHeader();
		t2.setBackground(new Color(75,0,130));
		t2.setForeground(Color.white);
		table1.setFont(new Font("Tahoma", Font.PLAIN, 16));
		table1.setSelectionBackground(new Color(0,128,128));
		table1.setSelectionForeground(Color.white);
		table1.setRowHeight(30);
		table1.getTableHeader().setFont(new Font("SansSerif", Font.BOLD, 18));
		table1.setBounds(0,500,450,200);
		table1.addMouseListener(this);
		sorter = new TableRowSorter<>(model);
		table1.setRowSorter(sorter);

	}

	public void mouseClicked(MouseEvent ae) {
		if (ae.getSource() == table1) {

			try {
				int h2 = table1.getSelectedRow();

				TableModel model = table1.getModel();

				String name = model.getValueAt(h2, 2).toString();
				bookingtxt.setText(name);

				Date date = new SimpleDateFormat("yyyy-MM-dd").parse((String) model.getValueAt(h2, 3));
				checkin.setDate(date);

				Date date2 = new SimpleDateFormat("yyyy-MM-dd").parse((String) model.getValueAt(h2, 4));
				checkout1.setDate(date2);

			} catch (Exception ex) {
				System.out.println("Erro" + ex.getMessage());
			}

		}

	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseEntered(MouseEvent e) {
		

	}

	@Override
	public void mouseExited(MouseEvent e) {
		

	}

	public static void main(String[] args) {
		new ReceptionDashboard();

	}
}
