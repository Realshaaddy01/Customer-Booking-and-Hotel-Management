package allgui.staffgui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.border.EtchedBorder;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableModel;

import com.toedter.calendar.JDateChooser;

import allModels.BookingModel1;
import allModels.BookingModel5;
import DBControllers.JDBCBooking;
import DBControllers.JDBCBooking2;
import DBControllers.JDBCRoom;
import allModels.RoomModel1;

public class CustomerCheckIn implements MouseListener {

	JFrame frame;
	Object[] columnsName;
	DefaultTableModel model;
	JTable table;
	JDateChooser c1,c2;
	ArrayList<BookingModel5> check;
	JButton insertbtn,cancelbtn;
	JTextField nametxt,roomidtxt,credittxt,bookingidtxt,roomtypetxt;
	JComboBox statustxt;

	public CustomerCheckIn() {

		frame = new JFrame("Today's Check-In Customers");
		frame.setIconImage(Toolkit.getDefaultToolkit().getImage(getClass().getResource("hotelicon1.png")));
		frame.setSize(1280, 720);
		frame.setLocationRelativeTo(null);
		frame.setLayout(new BorderLayout());
		frame.setResizable(false);

		// *******************Headpanel Panel***************
		JPanel Headpanel = new JPanel();
		Headpanel.setLayout(null);
		Headpanel.setPreferredSize(new Dimension(100, 120));
		Headpanel.setBackground(new Color(50, 60, 250));
		frame.add(Headpanel, BorderLayout.NORTH);	
		
		JLabel headlbl = new JLabel("CHECKIN PAGE");
		headlbl.setBounds(510, 0, 400, 50);
		headlbl.setFont(new Font("Monospaced", Font.BOLD, 40));
		headlbl.setForeground(Color.white);
		Headpanel.add(headlbl);
		
		JPanel searchpanel = new JPanel();
		searchpanel.setLayout(null);
		searchpanel.setBounds(0,70,1280,50);
//		searchpanel.setPreferredSize(new Dimension(100, 30));
		searchpanel.setBackground(new Color(0,0,128));	
		Headpanel.add(searchpanel);

		JLabel searchlbl = new JLabel("Search:");
		searchlbl.setBounds(928, 10, 100, 30);
		searchlbl.setFont(new Font("Tahoma", Font.BOLD, 20));
		searchlbl.setForeground(Color.white);
		searchpanel.add(searchlbl);

		JTextField searchtxt = new JTextField();
		searchtxt.setBounds(1028, 10, 200, 30);
		searchtxt.setBorder(BorderFactory.createLineBorder(Color.white, 1));
		searchtxt.setFont(new Font("Tahoma", Font.BOLD, 20));
		searchpanel.add(searchtxt);

		// *******************Center Panel***************
		JPanel center = new JPanel();
		center.setLayout(null);
		center.setBorder(new TitledBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(0, 0, 0), new Color(160, 250, 200)), "Customer Details", TitledBorder.LEADING, TitledBorder.TOP, new Font("Tahoma", Font.BOLD, 20), new Color(250,10,50)));
		center.setBackground(new Color(135,206,250));
		frame.add(center, BorderLayout.CENTER);
		
		JLabel namelbl = new JLabel("Name:");
		namelbl.setBounds(90, 50, 200, 30);
		namelbl.setFont(new Font("Tahoma", Font.BOLD, 20));
		namelbl.setForeground(Color.BLACK);
		center.add(namelbl);
		
		nametxt = new JTextField();
		nametxt.setBounds(240, 50, 230, 30);
		nametxt.setBorder(BorderFactory.createLineBorder(Color.white, 1));
		nametxt.setFont(new Font("Tahoma", Font.BOLD, 20));
		center.add(nametxt);
		
		JLabel creditlbl = new JLabel("Credit No:");
		creditlbl.setBounds(90, 100, 200, 30);
		creditlbl.setFont(new Font("Tahoma", Font.BOLD, 20));
		creditlbl.setForeground(Color.BLACK);
		center.add(creditlbl);
		
		credittxt = new JTextField();
		credittxt.setBounds(240, 100, 230, 30);
		credittxt.setBorder(BorderFactory.createLineBorder(Color.white, 1));
		credittxt.setFont(new Font("Tahoma", Font.BOLD, 20));
		center.add(credittxt);
		
		JLabel bookinglbl = new JLabel("Boooking ID:");
		bookinglbl.setBounds(90, 150, 200, 30);
		bookinglbl.setFont(new Font("Tahoma", Font.BOLD, 20));
		bookinglbl.setForeground(Color.BLACK);
		center.add(bookinglbl);
		
		bookingidtxt = new JTextField();
		bookingidtxt.setBounds(240, 150, 230, 30);
		bookingidtxt.setBorder(BorderFactory.createLineBorder(Color.white, 1));
		bookingidtxt.setFont(new Font("Tahoma", Font.BOLD, 20));
		center.add(bookingidtxt);
		
		JLabel roomidlbl = new JLabel("Room ID:");
		roomidlbl.setBounds(90, 200, 200, 30);
		roomidlbl.setFont(new Font("Tahoma", Font.BOLD, 20));
		roomidlbl.setForeground(Color.BLACK);
		center.add(roomidlbl);
		
		roomidtxt = new JTextField();
		roomidtxt.setBounds(240, 200, 230, 30);
		roomidtxt.setBorder(BorderFactory.createLineBorder(Color.white, 1));
		roomidtxt.setFont(new Font("Tahoma", Font.BOLD, 20));
		center.add(roomidtxt);
		
		//*****************Another Side*****************
		JLabel checkinlbl = new JLabel("Check-In:");
		checkinlbl.setBounds(600, 50, 200, 30);
		checkinlbl.setFont(new Font("Tahoma", Font.BOLD, 20));
		checkinlbl.setForeground(Color.BLACK);
		center.add(checkinlbl);
		
		c1 = new JDateChooser();
		c1.setDateFormatString("yyyy-MM-dd");
		c1.setBounds(750, 50, 230, 30);
		c1.setBorder(BorderFactory.createLineBorder(Color.white, 1));
		c1.setFont(new Font("Tahoma", Font.PLAIN, 20));
		center.add(c1);
		
		JLabel checkoutlbl = new JLabel("Check-Out:");
		checkoutlbl.setBounds(600, 100, 200, 30);
		checkoutlbl.setFont(new Font("Tahoma", Font.BOLD, 20));
		checkoutlbl.setForeground(Color.BLACK);
		center.add(checkoutlbl);
		
		c2 = new JDateChooser();
		c2.setDateFormatString("yyyy-MM-dd");
		c2.setBounds(750, 100, 230, 30);
		c2.setBorder(BorderFactory.createLineBorder(Color.white, 1));
		c2.setFont(new Font("Tahoma", Font.PLAIN, 20));
		center.add(c2);
		
		JLabel roomtype = new JLabel("Room Type:");
		roomtype.setBounds(600, 150, 200, 30);
		roomtype.setFont(new Font("Tahoma", Font.BOLD, 20));
		roomtype.setForeground(Color.BLACK);
		center.add(roomtype);
		
		roomtypetxt = new JTextField();
		roomtypetxt.setBounds(750, 150, 230, 30);
		roomtypetxt.setBorder(BorderFactory.createLineBorder(Color.white, 1));
		roomtypetxt.setFont(new Font("Tahoma", Font.BOLD, 20));
		center.add(roomtypetxt);
		
		JLabel statuslbl = new JLabel("Status:");
		statuslbl.setBounds(600, 200, 200, 30);
		statuslbl.setFont(new Font("Tahoma", Font.BOLD, 20));
		statuslbl.setForeground(Color.BLACK);
		center.add(statuslbl);
		
		String[]h1= {"Active","Inactive"};
		statustxt = new JComboBox(h1);
		statustxt.setBounds(750, 200, 230, 30);
		statustxt.setBorder(BorderFactory.createLineBorder(Color.white, 1));
		statustxt.setFont(new Font("Tahoma", Font.BOLD, 20));
		center.add(statustxt);
		
		insertbtn = new JButton("Check-In");		
		insertbtn.setBounds(1030, 50, 200, 35);
		insertbtn.setFont(new Font("Times New Roman", Font.BOLD, 20));
		insertbtn.setBackground(new Color(25,255,25));
		insertbtn.setForeground(new Color(255,255,255));
		insertbtn.setFocusable(false);
		center.add(insertbtn);
		insertbtn.addActionListener(new ActionListener() {
			
			
			
			
			@Override
			public void actionPerformed(ActionEvent e) {
				
				// *********Update Room Status***************
				RoomModel1 room = new RoomModel1();
				
				int room_id1 = Integer.parseInt(roomidtxt.getText());

				room.setId(room_id1);
				room.setStatus("Active");
				JDBCRoom jdbc1 = new JDBCRoom();
				boolean result1 = jdbc1.update1(room);
				
				
				
				int cusid = Integer.parseInt(bookingidtxt.getText());
				
				String Bookingtype=statustxt.getSelectedItem().toString();

				BookingModel1 booking = new BookingModel1();

				booking.setBooking_ID(cusid);				
				booking.setBooking_Status(Bookingtype);

				JDBCBooking2 jdbc = new JDBCBooking2();
				boolean result = jdbc.update(booking);

				if (result == true) {
					updateTable();
					ImageIcon i = new ImageIcon(getClass().getResource("hotel icon.png"));
					JOptionPane.showMessageDialog(null, "The customer is checked-in successfully!", "Luton Hotel", JOptionPane.WIDTH, i);
				}

			}

		

				
			
			
			
		});
		
		cancelbtn = new JButton("Cancel Booking");		
		cancelbtn.setBounds(1030, 100, 200, 35);
		cancelbtn.setFont(new Font("Times New Roman", Font.BOLD, 20));
		cancelbtn.setBackground(new Color(255,25,25));
		cancelbtn.setForeground(new Color(255,255,255));
		cancelbtn.setFocusable(false);
		center.add(cancelbtn);
		cancelbtn.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				if(e.getSource()==cancelbtn) {
					
					//**************Update Room*****************8
					int room_id1 = Integer.parseInt(roomidtxt.getText());

					RoomModel1 room = new RoomModel1();
					
					room.setId(room_id1);
					room.setStatus("Available");
					JDBCRoom jdbc1 = new JDBCRoom();
					boolean result = jdbc1.update1(room);
					
					
					
					
					
					BookingModel1 booking = new BookingModel1();

		           int cancelbooking=(Integer.parseInt(bookingidtxt.getText()));
		            booking.setBooking_ID(cancelbooking);

					JDBCBooking jdbc2 = new JDBCBooking();
					boolean result1 = jdbc2.delete(cancelbooking);
					if (result1 == true) {
						updateTable();
						
						ImageIcon i = new ImageIcon(getClass().getResource("hotel icon.png"));
						JOptionPane.showMessageDialog(null, "Your booking is cancelled", "Customer Management", JOptionPane.WIDTH, i);
					} else {
						ImageIcon i = new ImageIcon(getClass().getResource("hotel icon.png"));
						JOptionPane.showMessageDialog(null, "Error Occured!", "Customer Management", JOptionPane.WIDTH, i);
					}
					
					
				}
				
			}
			
			
			
		});
		
		JButton checkinbtn = new JButton("View Check-In");		
		checkinbtn.setBounds(1030, 150, 200, 35);
		checkinbtn.setFont(new Font("Times New Roman", Font.BOLD, 20));
		checkinbtn.setBackground(new Color(25,25,255));
		checkinbtn.setForeground(new Color(255,255,255));
		checkinbtn.setFocusable(false);
		center.add(checkinbtn);
		checkinbtn.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				new CheckInGUI();
				
			}
			
			
			
			
		});

		// ******************South Table*************************8
		columnsName = new Object[9];
		columnsName[0] = "Customer ID";
		columnsName[1] = "Name";
		columnsName[2] = "Credit Number";
		columnsName[3] = "Booking ID";
		columnsName[4] = "Check-In";
		columnsName[5] = "Check-Out";
		columnsName[6] = "Room ID";
		columnsName[7] = "Room Type";
		columnsName[8] = "Room Status";

		table = new JTable(model);

		model = (DefaultTableModel) table.getModel();
		model.setColumnIdentifiers(columnsName);
		updateTable();
		JScrollPane scroll1 = new JScrollPane(table);
		scroll1.setPreferredSize(new Dimension(200, 300));
		frame.add(scroll1, BorderLayout.SOUTH);

		frame.setVisible(true);

	}

	public void updateTable() {
		check = new JDBCBooking().CheckIn();
		model.setRowCount(0);
		for (BookingModel5 bookingLibs : check) {
			Object tmpRow[] = { bookingLibs.getCustomer_ID(),
					bookingLibs.getName(),
					bookingLibs.getCredit_Number(),
					bookingLibs.getBooking_ID(),
					bookingLibs.getCheckIn(),
					bookingLibs.getCheckOut(),
					bookingLibs.getRoom_ID(),
					bookingLibs.getBooking_Type(),
					bookingLibs.getBooking_Status()

			};

			model.addRow(tmpRow);
		}

		table = new JTable(model);
		JTableHeader t2 = table.getTableHeader();
		t2.setBackground(new Color(75,0,130));
		t2.setForeground(Color.white);
		table.setFont(new Font("Tahoma", Font.PLAIN, 16));
		table.setSelectionBackground(new Color(0,128,128));
		table.setSelectionForeground(Color.white);
		table.setRowHeight(30);
		table.getTableHeader().setFont(new Font("SansSerif", Font.BOLD, 18));
		table.addMouseListener(this);

		// table.setModel(model);
		// table.repaint();
	}
	
	public void mouseClicked(MouseEvent ae) {
		if (ae.getSource() == table) {
			
			try {
				int h2=table.getSelectedRow();
				
				TableModel model=table.getModel();
				
				String name=model.getValueAt(h2, 1).toString();
				nametxt.setText(name);
				
				String credit=model.getValueAt(h2, 2).toString();
				credittxt.setText(credit);
				
				String booking=model.getValueAt(h2, 3).toString();
				bookingidtxt.setText(booking);
				
				String room=model.getValueAt(h2, 6).toString();
				roomidtxt.setText(room);
				
				String type=model.getValueAt(h2, 7).toString();
				roomtypetxt.setText(type);
				
				String status=model.getValueAt(h2, 8).toString();
				statustxt.setSelectedItem(status);
				
				
				Date date = new SimpleDateFormat("yyyy-MM-dd").parse((String)model.getValueAt(h2, 4));
				c1.setDate(date);
				
				Date date2 = new SimpleDateFormat("yyyy-MM-dd").parse((String)model.getValueAt(h2, 5));
				c2.setDate(date2);
				
				
			}
			catch(Exception ex) {
				System.out.println("Error"+ex.getMessage());
			}
			
		}	
			
		}

	public static void main(String[] args) {
		new CustomerCheckIn();
	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

}
