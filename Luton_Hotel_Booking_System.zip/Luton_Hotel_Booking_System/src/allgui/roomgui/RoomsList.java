package allgui.roomgui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Toolkit;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;

import DBControllers.JDBCRoom;
import allModels.RoomModel1;




public class RoomsList {
	
	JFrame frame;
	JLabel customer;
	 JTable table;
	 JButton btn;
	 JScrollPane scrollPane;
	 DefaultTableModel modeltable;
	 
	public RoomsList() {
		frame=new JFrame("Available Rooms");
		frame.setSize(500,500);
		frame.setIconImage(Toolkit.getDefaultToolkit().getImage(getClass().getResource("hotelicon1.png")));
		frame.setResizable(false);
		frame.setLocationRelativeTo(null);
		frame.setLayout(new BorderLayout());
		
		JPanel HeadPanel=new JPanel();
		HeadPanel.setBackground(new Color(50,60,250));
		HeadPanel.setPreferredSize(new Dimension(100,80));
		HeadPanel.setLayout(new FlowLayout());
		frame.getContentPane().add(HeadPanel, BorderLayout.NORTH);
		
		customer=new JLabel("All AVAILABLE ROOMS", SwingConstants.CENTER);
		customer.setPreferredSize(new Dimension(350,70));
		customer.setForeground(Color.white);
		customer.setFont(new Font("Monospaced", Font.BOLD, 30));
		HeadPanel.add(customer);
		
		
		modeltable = new DefaultTableModel();
		table = new JTable(modeltable);
		JTableHeader h1=table.getTableHeader();
		h1.setBackground(new Color(70,0,130));
		h1.setForeground(Color.white);
		h1.setFont(new Font("Verdana", Font.BOLD,15));
		table.setFont(new Font("Verdana", Font.PLAIN,16));
		table.setRowHeight(20);
		table.setGridColor(Color.white);
		table.setSelectionBackground(new Color(0,128,128));
		table.setSelectionForeground(Color.white);
		
		modeltable.addColumn("Room-ID");
		modeltable.addColumn("Room Type");
		modeltable.addColumn("Room Rate");
		modeltable.addColumn("Status");
		
		
		RoomModel1 room=new RoomModel1();
		
		JDBCRoom jdbc2 = new JDBCRoom();
		ArrayList rooms = jdbc2.getAvailableRooms();
		if(rooms.size()>0) {
			for(int i=0; i<rooms.size(); i++) {
				RoomModel1 p = (RoomModel1) rooms.get(i);
				Object []tmp= {p.getId(),
						p.getType(),
						p.getRate(),
								p.getStatus(),
								};
				modeltable.addRow(tmp);
			}
		}
		scrollPane = new JScrollPane(table);
		frame.add(scrollPane, BorderLayout.CENTER);
		
		frame.setVisible(true);
		
	}

	public static void main(String[] args) {
		new RoomsList();
		

	}
}
