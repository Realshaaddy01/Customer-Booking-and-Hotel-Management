package allgui.roomgui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.util.ArrayList;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;

import DBControllers.Globalfile;
import DBControllers.JDBCRoom;
import allModels.RoomModel1;

public class RoomMgmt implements ActionListener, ItemListener{
	JFrame frame;
	JLabel RoomIdlbl, typelbl, ratelbl, statuslbl,Searchlbl;
	JTextField RoomIdtxt,ratetxt; 
	JPanel HeadPanel, topPanel, center;
	JTextField searchtxt;
	JButton searchbtn, addbtn, updatebtn, deletebtn,clearbtn;
	JComboBox statuscombo,typecombo;
	JTable table;
	JScrollPane scrollPane;
	DefaultTableModel modeltable;
	
	
	public RoomMgmt()  {
		frame=new JFrame("Room Management System");
		frame.setSize(1050,550);
		frame.setResizable(false);
		frame.setLocationRelativeTo(null);
		frame.setIconImage(Toolkit.getDefaultToolkit().getImage(getClass().getResource("hotelicon1.png")));
		frame.setLayout(new BorderLayout());
		
		HeadPanel=new JPanel();
		HeadPanel.setBackground(new Color(255,255,255));
		HeadPanel.setPreferredSize(new Dimension(100,220));
		HeadPanel.setLayout(null);
		frame.add(HeadPanel,BorderLayout.NORTH);
		
		topPanel=new JPanel();
		topPanel.setBackground(new Color(50,60,250));
		topPanel.setBounds(0,0,1050,60);
		topPanel.setLayout(null);
		HeadPanel.add(topPanel);
		
		Searchlbl=new JLabel("Search:");
		Searchlbl.setBounds(20,10,100,35);
		Searchlbl.setFont(new Font("Verdana", Font.BOLD,20));
		Searchlbl.setForeground(Color.white);
		topPanel.add(Searchlbl);
		
		searchtxt=new JTextField();
		searchtxt.setBounds(120,10,170,35);
		searchtxt.setFont(new Font("Verdana", Font.PLAIN,20));
		searchtxt.setBorder(BorderFactory.createLineBorder(Color.white,1));
		topPanel.add(searchtxt);
		
		searchbtn=new JButton("Find");
		searchbtn.setBounds(330,10,100,35);
		searchbtn.setFocusable(false);
		searchbtn.setForeground(Color.black);
		searchbtn.setBackground(new Color(175,238,238));
		searchbtn.setFont(new Font("Verdana", Font.PLAIN,20));
		searchbtn.setBorder(BorderFactory.createLineBorder(Color.white,1));
		searchbtn.addActionListener(this);
		topPanel.add(searchbtn);
		
		
		
		RoomIdlbl=new JLabel("ID:");
		RoomIdlbl.setBounds(20,90,100,35);
		RoomIdlbl.setFont(new Font("Verdana", Font.BOLD,20));
		HeadPanel.add(RoomIdlbl);
		
		RoomIdtxt=new JTextField();
		RoomIdtxt.setEditable(false);
		RoomIdtxt.setBounds(130,90,220,35);
		RoomIdtxt.setBorder(BorderFactory.createLineBorder(Color.white,1));
		RoomIdtxt.setFont(new Font("Verdana", Font.PLAIN,20));
		HeadPanel.add(RoomIdtxt);
		
		typelbl=new JLabel("Type:");
		typelbl.setBounds(20,150,100,35);
		typelbl.setFont(new Font("Verdana", Font.BOLD,20));
		HeadPanel.add(typelbl);
		
	
		typecombo = new JComboBox();
		for (int i = 0; i < Globalfile.ROOM_TYPES.length; i++) {
			typecombo.addItem(Globalfile.ROOM_TYPES[i]);
		}
		typecombo.setFont(new Font("Verdana", Font.PLAIN, 17));
		typecombo.addItemListener(this);
		typecombo.setBounds(130, 150, 220, 35);
		//set rate
		
		HeadPanel.add(typecombo);
		
		
		ratelbl=new JLabel("Rate:");
		ratelbl.setBounds(380,90,100,35);
		ratelbl.setFont(new Font("Verdana", Font.BOLD,20));
		HeadPanel.add(ratelbl);
		
		ratetxt=new JTextField();
		ratetxt.setBounds(520,90,220,35);
		ratetxt.setFont(new Font("Verdana", Font.PLAIN,20));
		HeadPanel.add(ratetxt);
		
		statuslbl=new JLabel("Status:");
		statuslbl.setBounds(380,150,100,35);
		statuslbl.setFont(new Font("Verdana", Font.BOLD,20));
		HeadPanel.add(statuslbl);
		
		statuscombo = new JComboBox();
		for (int i = 0; i < Globalfile.ROOM_STATUS.length; i++) {
			statuscombo.addItem(Globalfile.ROOM_STATUS[i]);
		}
		statuscombo.setFont(new Font("Verdana", Font.PLAIN, 17));
		statuscombo.setBounds(520, 150, 220, 35);
		HeadPanel.add(statuscombo);
		
		
		
		
		addbtn=new JButton("Add Record");
		addbtn.setBounds(780,70,200,35);
		addbtn.setBackground(new Color(30,255,50));
		addbtn.setForeground(Color.white);
		addbtn.setFont(new Font("Verdana", Font.PLAIN,20));
		addbtn.addActionListener(this);
		HeadPanel.add(addbtn);
		
		updatebtn=new JButton("Update Record");
		updatebtn.setBounds(780,120,200,35);
		updatebtn.setBackground(new Color(50,20,255));
		updatebtn.setForeground(Color.white);
		updatebtn.setFont(new Font("Verdana", Font.PLAIN,20));
		updatebtn.addActionListener(this);
		HeadPanel.add(updatebtn);
		
		
		clearbtn=new JButton("Clear");
		clearbtn.setFocusable(false);
		clearbtn.setBounds(450,10,100,35);
		clearbtn.setForeground(Color.black);
		clearbtn.setBackground(new Color(255,55,25));
		clearbtn.setFont(new Font("Verdana", Font.PLAIN,20));
		clearbtn.setBorder(BorderFactory.createLineBorder(Color.white,1));
		clearbtn.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent ae) {
			RoomIdtxt.setText("");
			typecombo.setSelectedIndex(0);
			ratetxt.setText("");
			statuscombo.setSelectedIndex(0);
			
		}
	
		});
		topPanel.add(clearbtn);
		
		
		modeltable = new DefaultTableModel();
		table = new JTable(modeltable);
		JTableHeader h1=table.getTableHeader();
		h1.setBackground(new Color(70,0,130));
		h1.setForeground(Color.white);
		h1.setFont(new Font("Verdana", Font.BOLD,18));
		table.setFont(new Font("Verdana", Font.PLAIN,16));
		table.setRowHeight(20);
		table.setSelectionBackground(new Color(0,128,128));
		table.setSelectionForeground(Color.white);
		
		modeltable.addColumn("Room ID");
		modeltable.addColumn("Room Type");
		modeltable.addColumn("Room Rate");
		modeltable.addColumn("Room Status");
		
		JDBCRoom jdbc2 = new JDBCRoom();
		ArrayList room = jdbc2.select_all();
		if(room.size()>0) {
			for(int i=0; i<room.size(); i++) {
				RoomModel1 p = (RoomModel1) room.get(i);
				Object []tmp= {p.getId(), 
								p.getType(), 
								p.getRate(),
								p.getStatus(),
								};
				modeltable.addRow(tmp);
			}
		}
		scrollPane = new JScrollPane(table);
		frame.add(scrollPane, BorderLayout.CENTER);

		frame.setVisible(true);

	}
	public void actionPerformed(ActionEvent ae) {
		if(ae.getSource()==addbtn) {

			RoomModel1 room = new RoomModel1();
			
			room.setType(typecombo.getSelectedItem().toString());
			room.setRate(Double.parseDouble(ratetxt.getText()));
			room.setStatus(statuscombo.getSelectedItem().toString());

			JDBCRoom jdbc = new JDBCRoom();
			boolean result = jdbc.insert(room);
			if (result == true) {

				JOptionPane.showMessageDialog(null, "Succesfully Saved Record. ");
			} else {
				JOptionPane.showMessageDialog(null, "Error in Saving Record.");
			}

		}
	
	else if (ae.getSource() == searchbtn) {

		RoomModel1 room = new RoomModel1();
		int rid=Integer.parseInt(searchtxt.getText());
		

		JDBCRoom jdbc = new JDBCRoom();
		room =jdbc.search(rid);
		if (room.getId() >0) {
			String type=room.getType();
			
			int roomid =room.getId();
			RoomIdtxt.setText(Integer.toString(roomid));
			
			if (type.equals("Single")) {
			typecombo.setSelectedIndex(0);
			
			}
			else if (type.equals("Double")) {
				typecombo.setSelectedIndex(1);
				}
			else if (type.equals("Deluxe")) {
				typecombo.setSelectedIndex(2);
				}
			
			double rate=room.getRate();
			ratetxt.setText(Double.toString(rate));
			
			String status=room.getStatus();
			if (status.equals("Available")) {
				statuscombo.setSelectedIndex(0);
				}
				else if (status.equals("Booked")) {
					statuscombo.setSelectedIndex(1);
					
				}
			
			JOptionPane.showMessageDialog(null, "Record Searched Succesfull.");
		} else {
			JOptionPane.showMessageDialog(null, "Error in Searching Record.");
		}

		}
if (ae.getSource() == updatebtn) {
			
			//get room info
			RoomModel1 room =new RoomModel1();
			room.setId(Integer.parseInt(RoomIdtxt.getText()));
			room.setType(typecombo.getSelectedItem().toString());
			room.setRate(Double.parseDouble(ratetxt.getText()));
			room.setStatus(statuscombo.getSelectedItem().toString());
			
			
			JDBCRoom jdbc=new JDBCRoom();
			boolean result=jdbc.update(room);
			if(result==true) {
				JOptionPane.showMessageDialog(null, "Room Status Succesfully Updated");
			}
			
			else {
				JOptionPane.showMessageDialog(null, "Error in Updating data");
			}
			
		}
	}
	@Override
	public void itemStateChanged(ItemEvent ie) {
		if(ie.getSource()==typecombo) {
			int index=typecombo.getSelectedIndex();
			ratetxt.setText(Double.toString(Globalfile.ROOM_PRICE[index]));
		}
		
	}
	public static void main(String[] args) {
		new RoomMgmt();

	}

}
