package allgui.customergui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Vector;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;

import com.toedter.calendar.JDateChooser;

import allModels.BookingModel1;
import allModels.BookingModel2;
import allModels.RoomModel1;
import allModels.RoundPanelModel;
import DBControllers.Globalfile;
import DBControllers.JDBCBooking;
import DBControllers.JDBCRoom;
import allgui.logingui.LoginPage;


public class CustomerDashboard implements ActionListener, MouseListener{
	JFrame WindowFrame;
	JDateChooser Checkin, Checkout;
	JComboBox txtBookingType;
	JButton BookingBtn;
	JTextField txtCustomerID, txtCancelBooking;
	Object[] Column;
	DefaultTableModel model;
	JTable table;
	TableRowSorter sort;
	JMenuBar menubar;
	JMenu Logout;
	
	public CustomerDashboard() {
		
		WindowFrame=new JFrame("Customer Dashboard");
		WindowFrame.setSize(1280,720);
		WindowFrame.setIconImage(Toolkit.getDefaultToolkit().getImage(getClass().getResource("hotelicon1.png")));
		WindowFrame.setExtendedState(WindowFrame.MAXIMIZED_BOTH);
		WindowFrame.setResizable(true);
		WindowFrame.setLayout(new BorderLayout());
		
		
		
		//------- Headingpanel Panel--------
		JPanel Headingpanel=new JPanel();
		Headingpanel.setLayout(null);
		Headingpanel.setBounds(0,0,1280,45);
		Headingpanel.setPreferredSize(new Dimension(100,45));
		Headingpanel.setBackground(new Color(50,60,250));
		WindowFrame.add(Headingpanel, BorderLayout.NORTH);
		
		JLabel title =new JLabel("Customer Dashboard");
		title.setForeground(Color.white);
		title.setPreferredSize(new Dimension(100,45));
		title.setBounds(600,0,400,50);
		title.setFont(new Font("Verdana", Font.BOLD, 30));
		Headingpanel.add(title);
		
		JButton LogoutBtn = new JButton("Logout");
		LogoutBtn.setBounds(35,6,130,32);
		LogoutBtn.setBackground(new Color(250,20,25));
		LogoutBtn.setForeground(new Color(255,255,255));
		LogoutBtn.setFont(new Font("Verdana", Font.BOLD, 22));
		Headingpanel.add(LogoutBtn);
		
		LogoutBtn.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent ae) {
				if(ae.getSource()==LogoutBtn) {
					WindowFrame.dispose();
					new LoginPage();
				}
			}	
			});
		
		//------------Center Panel---------------	
		JPanel center=new JPanel();
		center.setLayout(null);
		center.setPreferredSize(new Dimension(100,100));
		center.setBackground(new Color(243, 233, 210));
		WindowFrame.add(center, BorderLayout.CENTER);
		
		//-------------Profile Panel-----------------------
		RoundPanelModel profilePanel = new RoundPanelModel();
		profilePanel.setRoundBottomRight(100);
		profilePanel.setRoundBottomLeft(100);
		profilePanel.setRoundTopLeft(100);
		profilePanel.setRoundTopRight(100);
		profilePanel.setLayout(null);
		profilePanel.setBounds(5,25,370,620);
		profilePanel.setBackground(new Color(251,230,205,90));
		center.add(profilePanel, BorderLayout.CENTER);
		
		JLabel profile =new JLabel("My Profile");
		profile.setBounds(130,40,400,50);
		profile.setFont(new Font("Tahoma", Font.BOLD, 25));
		profilePanel.add(profile);
		
		
		JLabel nameLabel =new JLabel("Name:");
		nameLabel.setBounds(70,100,400,50);
		nameLabel.setFont(new Font("Tahoma", Font.BOLD, 16));
		profilePanel.add(nameLabel);
		
		JLabel name =new JLabel();
		name.setText(Globalfile.currentUser.getName());
		name.setBounds(170,100,400,50);
		name.setFont(new Font("Tahoma", Font.BOLD, 16));
		profilePanel.add(name);
		
		JLabel genderLabel =new JLabel("Gender:");
		genderLabel.setBounds(70,150,400,50);
		genderLabel.setFont(new Font("Tahoma", Font.BOLD, 16));
		profilePanel.add(genderLabel);
		
		
		JLabel gender =new JLabel();
		gender.setText(Globalfile.currentUser.getGender());
		gender.setBounds(170,150,400,50);
		gender.setFont(new Font("Tahoma", Font.BOLD, 16));
		profilePanel.add(gender);
		
		
		JLabel dobLabel =new JLabel("DOB:");
		dobLabel.setBounds(70,200,400,50);
		dobLabel.setFont(new Font("Tahoma", Font.BOLD, 16));
		profilePanel.add(dobLabel);
		
		
		JLabel dob =new JLabel();
		dob.setText(Globalfile.currentUser.getDOB());
		dob.setBounds(170,200,400,50);
		dob.setFont(new Font("Tahoma", Font.BOLD, 16));
		profilePanel.add(dob);
		
		
		JLabel mobileLabel =new JLabel("Mobile:");
		mobileLabel.setBounds(70,250,400,50);
		mobileLabel.setFont(new Font("Tahoma", Font.BOLD, 16));
		profilePanel.add(mobileLabel);
		
		JLabel mobile =new JLabel();
		mobile.setText(Globalfile.currentUser.getMobile());
		mobile.setBounds(170,250,400,50);
		mobile.setFont(new Font("Tahoma", Font.BOLD, 16));
		profilePanel.add(mobile);
		
		
		JLabel emailLabel =new JLabel("Email:");
		emailLabel.setBounds(70,300,400,50);
		emailLabel.setFont(new Font("Tahoma", Font.BOLD, 16));
		profilePanel.add(emailLabel);
		
		JLabel email =new JLabel();
		email.setText(Globalfile.currentUser.getEmail());
		email.setBounds(170,300,400,50);
		email.setFont(new Font("Tahoma", Font.BOLD, 16));
		profilePanel.add(email);
		
		
		JLabel addressLabel =new JLabel("Address:");
		addressLabel.setBounds(70,350,400,50);
		addressLabel.setFont(new Font("Tahoma", Font.BOLD, 16));
		profilePanel.add(addressLabel);
		
		
		JLabel address =new JLabel();
		address.setText(Globalfile.currentUser.getAddress());
		address.setBounds(170,350,400,50);
		address.setFont(new Font("Tahoma", Font.BOLD, 16));
		profilePanel.add(address);
		
		
		JLabel usernameLabel =new JLabel("Username:");
		usernameLabel.setBounds(70,400,400,50);
		usernameLabel.setFont(new Font("Tahoma", Font.BOLD, 16));
		profilePanel.add(usernameLabel);
		
		
		JLabel username =new JLabel();
		username.setText(Globalfile.currentUser.getUsername());
		username.setBounds(170,400,400,50);
		username.setFont(new Font("Tahoma", Font.BOLD, 16));
		profilePanel.add(username);
		
		
		JLabel passwordLabel =new JLabel("Password:");
		passwordLabel.setBounds(70,450,400,50);
		passwordLabel.setFont(new Font("Tahoma", Font.BOLD, 16));
		profilePanel.add(passwordLabel);
		
		
		JLabel password =new JLabel();
		password.setText(Globalfile.currentUser.getPassword());
		password.setBounds(170,450,400,50);
		password.setFont(new Font("Tahoma", Font.BOLD, 16));
		profilePanel.add(password);
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		//--------------------Booking Panel------------------
		RoundPanelModel bookingPanel = new RoundPanelModel();
		bookingPanel.setRoundBottomRight(100);
		bookingPanel.setRoundBottomLeft(100);
		bookingPanel.setRoundTopLeft(100);
		bookingPanel.setRoundTopRight(100);
		bookingPanel.setLayout(null);
		bookingPanel.setBounds(400,30,960,620);
		bookingPanel.setBackground(new Color(255,255,255));
		center.add(bookingPanel, BorderLayout.CENTER);
		
		
		JLabel bookinglbl=new JLabel("CHECK FOR BOOKING", SwingConstants.CENTER);
		bookinglbl.setBounds(300,10,400,35);
		bookinglbl.setFont(new Font("Monospaced",Font.BOLD,35));
		bookingPanel.add(bookinglbl);
		
		txtCancelBooking=new JTextField();
		txtCancelBooking.setVisible(false);
		bookingPanel.add(txtCancelBooking);
		
		JLabel CheckinLabel=new JLabel("Arrival Date: ");
		CheckinLabel.setBounds(70,100,200,35);
		CheckinLabel.setFont(new Font("Verdana",Font.PLAIN,18));
		bookingPanel.add(CheckinLabel);
		
		Date date=new Date();
		
		Checkin = new JDateChooser();
		Checkin.setMinSelectableDate(date);
        Checkin.setDateFormatString("yyyy-MM-dd");
		Checkin.setBorder(BorderFactory.createLineBorder(Color.WHITE,1));
		Checkin.setFont(new Font("Verdana",Font.PLAIN,18));
		Checkin.setBounds(230,100,200,30);
		bookingPanel.add(Checkin);
		
		
		JLabel checkoutLabel=new JLabel("Departure Date: ");
		checkoutLabel.setBounds(70,150,200,35);
		checkoutLabel.setFont(new Font("Verdana",Font.PLAIN,18));
		bookingPanel.add(checkoutLabel);
		
		Checkout = new JDateChooser();
		Checkout.setMinSelectableDate(date);
		Checkout.setDateFormatString("yyyy-MM-dd");
		Checkout.setBorder(BorderFactory.createLineBorder(Color.WHITE,1));
		Checkout.setFont(new Font("Verdana",Font.PLAIN,18));
		Checkout.setBounds(230,150,200,30);
		bookingPanel.add(Checkout);
		
		
		JLabel bookingtype=new JLabel("Room Type:");
		bookingtype.setBounds(550,100,200,35);
		bookingtype.setFont(new Font("Verdana",Font.PLAIN,18));
		bookingPanel.add(bookingtype);
		
		Object[] h1= {"Single","Double","Deluxe","Twin"};
		
		txtBookingType=new JComboBox(h1);
		txtBookingType.setBorder(BorderFactory.createLineBorder(Color.WHITE,1));
		txtBookingType.setBounds(690,100,200,30);
		txtBookingType.setFont(new Font("Verdana",Font.PLAIN,18));
		bookingPanel.add(txtBookingType);
		
		
		JButton bookingclearbtn=new JButton("Clear");
		bookingclearbtn.setBounds(490,200,100,35);
		bookingclearbtn.setFocusable(false);
		bookingclearbtn.setBackground(new Color(184,134,11));
		bookingclearbtn.setForeground(Color.white);
		bookingclearbtn.setFont(new Font("Verdana",Font.PLAIN,18));
		bookingPanel.add(bookingclearbtn);
		bookingclearbtn.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent ae) {
				if(ae.getSource()==bookingclearbtn) {	
					
					Checkin.setCalendar(null);
					Checkout.setCalendar(null);
					txtBookingType.setSelectedIndex(0);

				}}});
		
		
		txtCustomerID=new JTextField();
		txtCustomerID.setVisible(false);
		txtCustomerID.setText(Integer.toString(Globalfile.currentUser.getCustomer_ID()));
		bookingPanel.add(txtCustomerID);
		
		
		BookingBtn=new JButton("Book Room");
		BookingBtn.setFocusable(false);
		BookingBtn.setBounds(240,200,150,35);
		BookingBtn.setBackground(new Color(0,255,127));
		BookingBtn.setForeground(new Color(255,255,255));
		BookingBtn.addActionListener(this);
		BookingBtn.setFont(new Font("Verdana",Font.PLAIN,18));
		bookingPanel.add(BookingBtn);
		
		JButton cancelRoombtn=new JButton("Cancel Booking");
		cancelRoombtn.setFocusable(false);
		cancelRoombtn.setBounds(680,200,185,35);	
		cancelRoombtn.setBackground(new Color(255,20,40));
		cancelRoombtn.setForeground(Color.white);
		cancelRoombtn.setFont(new Font("Verdana",Font.PLAIN,18));
		bookingPanel.add(cancelRoombtn);
		cancelRoombtn.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				if(e.getSource()==cancelRoombtn) {
					BookingModel1 booking = new BookingModel1();
					
		           int cancelbooking=(Integer.parseInt(txtCancelBooking.getText()));
		            
					
		            
		            booking.setBooking_ID(cancelbooking);
		          

					JDBCBooking jdbc2 = new JDBCBooking();
					boolean result1 = jdbc2.delete(cancelbooking);
					if (result1 == true) {
						update();
						
						ImageIcon i = new ImageIcon(getClass().getResource("hotelicon1.png"));
						JOptionPane.showMessageDialog(null, "Your booking is cancelled", "Customer Management", JOptionPane.WIDTH, i);
					} else {
						ImageIcon i = new ImageIcon(getClass().getResource("hotelicon1.png"));
						JOptionPane.showMessageDialog(null, "Error Occured!", "Customer Management", JOptionPane.WIDTH, i);
					}
					
					
				}
				
			}
			
			
			
		});
		

		//------------------------Booking Table-----------------------
		
		Column = new Object[7];
		
		Column[0] = "Name";
		Column[1] = "Booking ID";
		Column[2] = "Check-In";
		Column[3] = "Check-Out";
		Column[4] = "Room Type";
		Column[5] = "Room ID";
		Column[6] = "Room Status";

		table = new JTable();
		model = (DefaultTableModel) table.getModel();
		model.setColumnIdentifiers(Column);

		update();
		
		
		JTableHeader heading = table.getTableHeader();
		heading.setBackground(new Color(75,0,130));
		heading.setForeground(Color.white);
		heading.setFont(new Font("Verdana", Font.BOLD, 15));
		table.setFont(new Font("Verdana", Font.PLAIN, 16));
		table.setRowHeight(20);
		table.setBackground(new Color(255,255,240));
		table.setSelectionBackground(new Color(0,128,128));
		table.setSelectionForeground(Color.white);
		table.setBorder(null);
		sort = new TableRowSorter<>(model);
		table.setRowSorter(sort);
		table.addMouseListener(this);
		
		
		JScrollPane scroll1 = new JScrollPane(table);
		scroll1.setBounds(0, 260, 960, 300);
		scroll1.setBorder( null );
		bookingPanel.add(scroll1);

		
		
		WindowFrame.setVisible(true);
		
		
	}
	
	
          public void actionPerformed(ActionEvent ae) {
		
		if(ae.getSource()==BookingBtn) {
			
            

			int cusid=Integer.parseInt(txtCustomerID.getText());
			String str1 = ((JTextField)Checkin.getDateEditor().getUiComponent()).getText();
            String str2 = ((JTextField)Checkout.getDateEditor().getUiComponent()).getText();
     
            String bookingtype1=txtBookingType.getSelectedItem().toString();
            
            
                   
            BookingModel1 booking=new BookingModel1();
            
            booking.setCustomer_ID(cusid);
            booking.setCheckIn(str1);
            booking.setCheckOut(str2);
            booking.setBooking_Type(bookingtype1);
            booking.setBooking_Status("Requested");
            
            
            JDBCBooking jdbc=new JDBCBooking();
            boolean result=jdbc.insert(booking);
            
            if(result==true) {
            	
            	update();
            	
            	ImageIcon i=new ImageIcon(getClass().getResource("hotel icon.png"));
				JOptionPane.showMessageDialog(null, "You have requested successfully","Room Booking",JOptionPane.WIDTH,i);
            }

		
		}
	}
          
          
          
          
          
          private void update() {
     		 JDBCBooking jdbc = new JDBCBooking();
     			ArrayList Booking = jdbc.view_all1();
     			model.setRowCount(0);
     			if (Booking.size() > 0) {
     	            for (int i = 0; i < Booking.size(); i++) {
     	            	BookingModel2 tmp_person = (BookingModel2) Booking.get(i);
     	                
     	                Vector tmpPerson = new Vector();
     	                
     	                tmpPerson.add(tmp_person.getName());
     	                tmpPerson.add(tmp_person.getBooking_ID());
     	                tmpPerson.add(tmp_person.getCheckIn());
     	                tmpPerson.add(tmp_person.getCheckOut());
     	                tmpPerson.add(tmp_person.getBooking_Type());
     	                tmpPerson.add(tmp_person.getRoom_ID());
     	                tmpPerson.add(tmp_person.getBooking_Status());
     	                
     	               
     	                
     	                model.addRow(tmpPerson);
     	            }
     	        }
     	    }      
          
          
          
          @Override
      	public void mouseClicked(MouseEvent e) {
      		
      		if(e.getSource()==table) {
      			
      			try {
      				
      				int tab1=table.getSelectedRow();
      				
      				DefaultTableModel model1 =(DefaultTableModel) table.getModel();
      				
      				TableModel tab11=table.getModel();
      				
      				String custoid=tab11.getValueAt(tab1, 1).toString();
      				txtCancelBooking.setText(custoid);
      				
      				Date date = new SimpleDateFormat("yyyy-MM-dd").parse((String)model1.getValueAt(tab1, 2));
      				Checkin.setDate(date);
      				
      				Date date1 = new SimpleDateFormat("yyyy-MM-dd").parse((String)model1.getValueAt(tab1, 3));
      				Checkout.setDate(date1);
      				
      				String statustxt=tab11.getValueAt(tab1, 4).toString();
      				txtBookingType.setSelectedItem(statustxt);
      				
      				
      				
      			}
      			
      		catch(Exception ex) {
      			System.out.println("Error"+ex.getMessage());
      		}
      		
      		
      		
      		
      		
      		}}     
          
          
          

	public static void main(String[] args) {
		new CustomerDashboard();

	}


	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	

}
