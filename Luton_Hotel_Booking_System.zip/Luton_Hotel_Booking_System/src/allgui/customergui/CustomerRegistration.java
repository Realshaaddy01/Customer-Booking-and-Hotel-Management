package allgui.customergui;
 

import java.awt.BorderLayout;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Frame;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

import com.toedter.calendar.JDateChooser;

import allModels.CustomerModel1;
import DBControllers.JDBCCustomer;
import regExpression.RegexExpression;
import allgui.logingui.LoginPage;

public class CustomerRegistration implements ActionListener  {
//	private static final Integer Interger = null;
	JFrame frame;
	JPanel panel, panel1, panel3;

	JTextField txtName, txtMobile, txtEmail, txtAddress, txtUsername, txtCredit;
	JComboBox titlebox, genderCombo, roleCombo;
	JPasswordField txtPassword;
	JDateChooser txtDOB;

	JButton receptionregister, managerRegister, Clearbtn, RegisterBtn, LoginBtn;
	

	public CustomerRegistration() {
		frame = new JFrame();
		frame.setTitle("Customer Account Registration Form");
		frame.setIconImage(Toolkit.getDefaultToolkit().getImage(getClass().getResource("hotelicon1.png")));
		frame.setResizable(true);
		frame.setSize(950, 500);
		frame.setLocationRelativeTo(null);
		frame.getContentPane().setBackground(Color.WHITE);
		frame.setDefaultCloseOperation(frame.EXIT_ON_CLOSE);
		frame.setExtendedState(Frame.MAXIMIZED_BOTH);
		frame.setLayout(new BorderLayout());

		panel = new JPanel();
		panel.setBackground(new Color(50,60,250));
		panel.setPreferredSize(new Dimension(0, 50));
		frame.add(panel, BorderLayout.NORTH);

		panel1 = new JPanel();
		panel1.setBackground(new Color(255, 255, 255));
		panel1.setPreferredSize(new Dimension(480, 90));
		frame.add(panel1, BorderLayout.WEST);

		JLabel background = new JLabel("");
		Image img1 = new ImageIcon(this.getClass().getResource("registration.png")).getImage();
		background.setIcon(new ImageIcon(img1));
		background.setBounds(0, 0, 480, 600);
		panel1.add(background);


		JPanel main = new JPanel();
		main.setLayout(null);
		frame.add( main);

		JPanel main1 = new JPanel();
		main1.setBackground(new Color(255, 255, 255));
		main1.setBounds(0, 0, 950, 40);
		main.add(main1);

		JLabel customer = new JLabel("Fill Customer Details Form", SwingConstants.CENTER);
		customer.setForeground(new Color(25, 25, 112));
		customer.setPreferredSize(new Dimension(400, 30));
		customer.setFont(new Font("Verdana", Font.PLAIN, 25));
		customer.setBounds(10, 10, 200, 30);
		main1.add(customer);

		JLabel titlelbl = new JLabel("Title: ");
		titlelbl.setBounds(50, 120, 230, 25);
		titlelbl.setFont(new Font("Verdana", Font.PLAIN, 20));
		main.add(titlelbl);

		String title1[] = { "Mr.", "Mrs.", "Miss." };
		titlebox = new JComboBox(title1);
		titlebox.setBounds(190, 120, 230, 30);
		titlebox.setFont(new Font("Verdana", Font.PLAIN, 20));
		main.add(titlebox);

		JLabel Namelbl = new JLabel("Name: ");
		Namelbl.setBounds(50, 180, 230, 25);
		Namelbl.setFont(new Font("Verdana", Font.PLAIN, 20));
		main.add(Namelbl);

		txtName = new JTextField();
		txtName.setBounds(190, 180, 230, 30);
		txtName.setFont(new Font("Verdana", Font.PLAIN, 20));
		main.add(txtName);

		JLabel Genderlbl = new JLabel("Gender: ");
		Genderlbl.setBounds(50, 240, 230, 25);
		Genderlbl.setFont(new Font("Verdana", Font.PLAIN, 20));
		main.add(Genderlbl);

		String G1[] = { "Male", "Female", "Other" };
		genderCombo = new JComboBox(G1);
		genderCombo.setBounds(190, 240, 230, 30);
		genderCombo.setFont(new Font("Verdana", Font.PLAIN, 20));
		main.add(genderCombo);

		JLabel DOBlbl = new JLabel("DOB: ");
		DOBlbl.setBounds(50, 300, 230, 25);
		DOBlbl.setFont(new Font("Verdana", Font.PLAIN, 20));
		main.add(DOBlbl);

		txtDOB = new JDateChooser();
		txtDOB.setDateFormatString("yyyy-MM-dd");
		txtDOB.setBounds(190, 300, 230, 30);
		txtDOB.setFont(new Font("Verdana", Font.PLAIN, 20));
		main.add(txtDOB);

		JLabel Mobilelbl = new JLabel("Mobile No: ");
		Mobilelbl.setBounds(50, 360, 230, 25);
		Mobilelbl.setFont(new Font("Verdana", Font.PLAIN, 20));
		main.add(Mobilelbl);

		txtMobile = new JTextField();
		txtMobile.setBounds(190, 360, 230, 30);
		txtMobile.setFont(new Font("Verdana", Font.PLAIN, 20));
		main.add(txtMobile);

		JLabel Emaillbl = new JLabel("Email: ");
		Emaillbl.setBounds(50, 420, 230, 25);
		Emaillbl.setFont(new Font("Verdana", Font.PLAIN, 20));
		main.add(Emaillbl);

		txtEmail = new JTextField();
		txtEmail.setBounds(190, 420, 230, 30);
		txtEmail.setFont(new Font("Verdana", Font.PLAIN, 20));
		main.add(txtEmail);

		JLabel Addresslbl = new JLabel("Address: ");
		Addresslbl.setBounds(480, 120, 230, 25);
		Addresslbl.setFont(new Font("Verdana", Font.PLAIN, 20));
		main.add(Addresslbl);

		txtAddress = new JTextField();
		txtAddress.setBounds(630, 120, 230, 30);
		txtAddress.setFont(new Font("Verdana", Font.PLAIN, 20));
		main.add(txtAddress);

		JLabel Usernamelbl = new JLabel("Username: ");
		Usernamelbl.setBounds(480, 180, 230, 25);
		Usernamelbl.setFont(new Font("Verdana", Font.PLAIN, 20));
		main.add(Usernamelbl);

		txtUsername = new JTextField();
		txtUsername.setBounds(630, 180, 230, 30);
		txtUsername.setFont(new Font("Verdana", Font.PLAIN, 20));
		main.add(txtUsername);

		JLabel Passwordlbl = new JLabel("Password: ");
		Passwordlbl.setBounds(480, 240, 230, 25);
		Passwordlbl.setFont(new Font("Verdana", Font.PLAIN, 20));
		main.add(Passwordlbl);

		txtPassword = new JPasswordField();
		txtPassword.setBounds(630, 240, 230, 30);
		txtPassword.setFont(new Font("Verdana", Font.PLAIN, 20));
		main.add(txtPassword);

		JLabel Creditlbl = new JLabel("Credit No: ");
		Creditlbl.setBounds(480, 300, 230, 25);
		Creditlbl.setFont(new Font("Verdana", Font.PLAIN, 20));
		main.add(Creditlbl);

		txtCredit = new JTextField();
		txtCredit.setBounds(630, 300, 230, 30);
		txtCredit.setFont(new Font("Verdana", Font.PLAIN, 20));
		main.add(txtCredit);

		JLabel Rolelbl = new JLabel("Role: ");
		Rolelbl.setBounds(480, 360, 230, 25);
		Rolelbl.setFont(new Font("Verdana", Font.PLAIN, 20));
		main.add(Rolelbl);

		Object[] R1 = { "Individual", "Corp User" };
		roleCombo = new JComboBox(R1);
		roleCombo.setBounds(630, 360, 230, 30);
		roleCombo.setFont(new Font("Verdana", Font.PLAIN, 20));
		main.add(roleCombo);

		RegisterBtn = new JButton("Submit");
		RegisterBtn.setFocusable(false);
		RegisterBtn.setBounds(230, 500, 130, 40);
		RegisterBtn.setBackground(new Color(50,20,255));
		RegisterBtn.setForeground(Color.WHITE);
		RegisterBtn.setFont(new Font("Verdana", Font.PLAIN, 20));
		RegisterBtn.addActionListener(this);
		main.add(RegisterBtn);
		RegisterBtn.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				RegexExpression val = new RegexExpression();

				if (e.getSource() == RegisterBtn) {

					String Name = txtName.getText();
					boolean resultFName = val.Name(Name);
					if (resultFName == true) {
						
						String Gender = genderCombo.getSelectedItem().toString();
						boolean Gender1 = val.Gender(Gender);
						if (Gender1 == true) {
							
							String number = txtMobile.getText();
							boolean result = val.Phone(number);
							if (result == true) {
								
								String email = txtEmail.getText();
								boolean emailresult = val.Email(email);
								if (emailresult == true) {
									
									String username=txtUsername.getText();
									boolean resultusername=val.UserName(username);
									if(resultusername==true) {
										
										String password=String.valueOf(txtPassword.getPassword());
										boolean resultpassword=val.Password(password);
										if(resultpassword==true) {
											// save
											String title = titlebox.getSelectedItem().toString();
											String name = txtName.getText();
											String gender = genderCombo.getSelectedItem().toString();
											String DOB = ((JTextField) txtDOB.getDateEditor().getUiComponent()).getText();
											String mobile = txtMobile.getText();
											String email1 = txtEmail.getText();
											String address = txtAddress.getText();
											String username1 = txtUsername.getText();
											String password1 = String.valueOf(txtPassword.getPassword());
											String credit = txtCredit.getText();
											String role = roleCombo.getSelectedItem().toString();

											CustomerModel1 customer = new CustomerModel1();

											customer.setTitle(title);
											customer.setName(name);
											customer.setGender(gender);
											customer.setDOB(DOB);
											customer.setMobile(mobile);
											customer.setEmail(email1);
											customer.setAddress(address);
											customer.setUsername(username1);
											customer.setPassword(password1);
											customer.setCredit_Number(credit);
											customer.setRole(role);

											JDBCCustomer jdbc = new JDBCCustomer();
											boolean result1 = jdbc.insert(customer);
											if (result == true) {

												ImageIcon i = new ImageIcon(getClass().getResource("hotel icon.png"));
												JOptionPane.showMessageDialog(null, "You have registered your account successfully!",

														"Luton Hotel System", JOptionPane.WIDTH, i);
												new LoginPage();
												frame.dispose();
											}

											else {
												ImageIcon i = new ImageIcon(getClass().getResource("hotel icon.png"));
												JOptionPane.showMessageDialog(null, "Error Occured!", "Luton Hotel System", JOptionPane.WIDTH, i);
											}
											
											
											
										}
										else {
											JOptionPane.showMessageDialog(null, "Please enter proper password!");
										}
										
										
									}
									else {
										JOptionPane.showMessageDialog(null, "Please enter proper Username!");
									}
									
								}
								else {
									JOptionPane.showMessageDialog(null, "Invalid Email");
								}
								
								
							}
							else {
								JOptionPane.showMessageDialog(null, "Invalid Mobile Number");
							}
	

					}
						else {
							JOptionPane.showMessageDialog(null, "Invalid Gender");
						}

					

					}
					else {
						JOptionPane.showMessageDialog(null, "Invalid Name");
					}
					

				}

			}
			
			

		});


		Clearbtn = new JButton("Clear All");
		Clearbtn.setBounds(390, 500, 130, 40);
		Clearbtn.setBackground(new Color(205,50,20));
		Clearbtn.setForeground(Color.WHITE);
		Clearbtn.setFont(new Font("Verdana", Font.PLAIN, 20));
		Clearbtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {

			}

		});
		main.add(Clearbtn);

		LoginBtn = new JButton("Back");
		LoginBtn.setBounds(550, 500, 130, 40);
		LoginBtn.setBackground(new Color(25,255,50));
		LoginBtn.setForeground(Color.WHITE);
		LoginBtn.setFont(new Font("Verdana", Font.PLAIN, 20));
		LoginBtn.addActionListener(this);
		main.add(LoginBtn);
		LoginBtn.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				frame.dispose();
				new LoginPage();

			}

		});

		JLabel title = new JLabel("CUSTOMER REGISTRATION", SwingConstants.CENTER);
		title.setForeground(Color.WHITE);
		title.setFont(new Font("Verdana", Font.BOLD, 25));
		title.setBounds(300,0,950,40);
		panel.add(title);
		frame.setVisible(true);
	}

	@Override
	public void actionPerformed(ActionEvent ae) {
		if (ae.getSource() == RegisterBtn) {

			if (txtName.getText().trim().isEmpty() || txtAddress.getText().trim().isEmpty()
					|| txtMobile.getText().trim().isEmpty() || txtEmail.getText().trim().isEmpty()
					|| txtUsername.getText().trim().isEmpty() || String.valueOf(txtPassword.getPassword()).trim().isEmpty()
					|| txtCredit.getText().trim().isEmpty()) {
				ImageIcon i2 = new ImageIcon(getClass().getResource("hotel icon.png"));
				JOptionPane.showMessageDialog(null, "Please fill all the details!", "Luton Hotel System",
						JOptionPane.WIDTH, i2);
			}

			else {

				

			}
		}

	}

	public static void main(String[] args) {
		new CustomerRegistration();

	}

}
