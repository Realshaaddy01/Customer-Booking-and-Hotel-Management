package allgui.billinggui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.print.PageFormat;
import java.awt.print.Printable;
import java.awt.print.PrinterException;
import java.awt.print.PrinterJob;
import java.util.Random;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JSeparator;

import DBControllers.Globalfile;

public class Billgui {
	JFrame WindowFrame;
	
	public Billgui() {
		WindowFrame = new JFrame("Invoice");
		WindowFrame.setSize(450, 600);
		WindowFrame.setLocationRelativeTo(null);
		WindowFrame.setResizable(false);
		WindowFrame.setLayout(new BorderLayout());
		WindowFrame.setBackground(new Color(255,178,102));
		WindowFrame.setIconImage(Toolkit.getDefaultToolkit().getImage(getClass().getResource("hotelicon1.png")));
		
		
		
		JPanel center=new JPanel();
		center.setLayout(null);
		center.setBackground(new Color(210,220,200,90));
		WindowFrame.add(center, BorderLayout.CENTER);
		
		JMenuBar menubar = new JMenuBar();
		WindowFrame.setJMenuBar(menubar);
		
		JMenu menu = new JMenu("Print Invoice");
		menu.setBackground(new Color(255,153,255));
		menubar.add(menu);

		JMenuItem print = new JMenuItem("Print Bill");
		print.setBackground(new Color(20,255,60));
		menu.add(print);
		print.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {

				PrinterJob job = PrinterJob.getPrinterJob();
				job.setJobName("Print Data");

				job.setPrintable(new Printable() {
					public int print(Graphics pg, PageFormat pf, int pageNum) {
						pf.setOrientation(PageFormat.LANDSCAPE);
						if (pageNum > 0) {
							return Printable.NO_SUCH_PAGE;
						}

						Graphics2D g2 = (Graphics2D) pg;
						g2.translate(pf.getImageableX(), pf.getImageableY());
						g2.scale(0.85, 0.70);

						center.print(g2);

						return Printable.PAGE_EXISTS;

					}
				});
				boolean ok = job.printDialog();
				if (ok) {
					try {

						job.print();
					} catch (PrinterException ex) {
						ex.printStackTrace();
					}
				}

			}

		});

		
		JLabel header=new JLabel("########********########********########********########********########********########********########");
		header.setBounds(0,5,450,10);
		header.setBackground(new Color(50,60,250));
		center.add(header);
		
		JLabel title=new JLabel("LUTON HOTEL PAYMENT BILL");
		title.setFont(new Font("Monospaced", Font.BOLD, 27));
		title.setBounds(30,20,350,31);
		center.add(title);
		
		JLabel title1=new JLabel("Luton, UK");
		title1.setFont(new Font("Monospaced", Font.PLAIN, 22));
		title1.setBounds(160,50,200,23);
		center.add(title1);
		
		JSeparator j1=new JSeparator();
		j1.setBounds(100,75,220,10);
		center.add(j1);
		
		
		JLabel invoiceno = new JLabel("Invoice No:");
		invoiceno.setFont(new Font("Brush Script", Font.PLAIN, 17));
		invoiceno.setBounds(20, 110, 230, 20);
		center.add(invoiceno);

		Random rand=new Random();
		int random=(int) (Math.random()*10569900+1);
		
		JLabel invoicenolbl = new JLabel();
		invoicenolbl.setText(String.valueOf(random));
		invoicenolbl.setFont(new Font("Consolas", Font.PLAIN, 17));
		invoicenolbl.setBounds(200, 110, 230, 20);
		center.add(invoicenolbl);
		
		
		JLabel custName = new JLabel("Name:");
		custName.setFont(new Font("Brush Script", Font.PLAIN, 17));
		custName.setBounds(20, 160, 230, 20);
		center.add(custName);
		
		JLabel custNameLabel = new JLabel("");
		custNameLabel.setText(Globalfile.currentBilling.getName());
		custNameLabel.setFont(new Font("Consolas", Font.PLAIN, 17));
		custNameLabel.setBounds(170, 160, 230, 20);
		center.add(custNameLabel);
		
		JLabel BillingStatus = new JLabel("Status:");
		BillingStatus.setFont(new Font("Brush Script", Font.PLAIN, 17));
		BillingStatus.setBounds(20, 190, 230, 20);
		center.add(BillingStatus);
		
		JLabel BillingLabel = new JLabel("Paid");
		BillingLabel.setText(Globalfile.currentBilling.getBilling_Status());
		BillingLabel.setFont(new Font("Consolas", Font.PLAIN, 17));
		BillingLabel.setBounds(170, 190, 230, 20);
		center.add(BillingLabel);
		
		JLabel BookingID = new JLabel("Booking ID:");
		BookingID.setFont(new Font("Brush Script", Font.PLAIN, 17));
		BookingID.setBounds(20, 220, 230, 22);
		center.add(BookingID);
		
		JLabel BookingIDLabel = new JLabel("");
		BookingIDLabel.setText(Integer.toString(Globalfile.currentBilling.getBooking_ID()));
		BookingIDLabel.setFont(new Font("Consolas", Font.PLAIN, 17));
		BookingIDLabel.setBounds(170, 220, 230, 20);
		center.add(BookingIDLabel);
		
		JLabel RoomPrice = new JLabel("Room Amount:");
		RoomPrice.setFont(new Font("Brush Script", Font.PLAIN, 17));
		RoomPrice.setBounds(20, 250, 230, 20);
		center.add(RoomPrice);
		
		JLabel RoomPriceLabel = new JLabel("");
		RoomPriceLabel.setText(Integer.toString(Globalfile.currentBilling.getRoom_Price()));
		RoomPriceLabel.setFont(new Font("Consolas", Font.PLAIN, 17));
		RoomPriceLabel.setBounds(170, 250, 230, 20);
		center.add(RoomPriceLabel);
		
		JLabel Middle=new JLabel("-------------------------------------------------------------------------------------------------------");
		Middle.setBounds(10,300,450,10);
		center.add(Middle);
		
		
		JLabel VAT = new JLabel("VAT:");
		VAT.setFont(new Font("Brush Script", Font.PLAIN, 17));
		VAT.setBounds(160, 330, 230, 20);
		center.add(VAT);
		
		JLabel VATLabel = new JLabel("");
		VATLabel.setText(Integer.toString(Globalfile.currentBilling.getVAT()));
		VATLabel.setFont(new Font("Consolas", Font.PLAIN, 17));
		VATLabel.setBounds(330, 330, 230, 20);
		center.add(VATLabel);
		
		JLabel Service = new JLabel("Service Charge:");
		Service.setFont(new Font("Brush Script", Font.PLAIN, 17));
		Service.setBounds(160, 360, 230, 22);
		center.add(Service);
		
		JLabel ServiceLabel = new JLabel("");
		ServiceLabel.setText(Integer.toString(Globalfile.currentBilling.getService_Charge()));
		ServiceLabel.setFont(new Font("Consolas", Font.PLAIN, 17));
		ServiceLabel.setBounds(330, 360, 230, 20);
		center.add(ServiceLabel);
		
		JLabel Total = new JLabel("Total Bill:");
		Total.setFont(new Font("Brush Script", Font.PLAIN, 17));
		Total.setBounds(160, 390, 230, 22);
		center.add(Total);
		
		JLabel TotalLabel = new JLabel("");
		TotalLabel.setText(Double.toString(Globalfile.currentBilling.getTotal_Bill()));
		TotalLabel.setFont(new Font("Consolas", Font.PLAIN, 17));
		TotalLabel.setBounds(330, 390, 230, 20);
		center.add(TotalLabel);
		
		JLabel Thank = new JLabel("Thank you and visit us again!");
		Thank.setFont(new Font("Brush Script", Font.PLAIN, 18));
		Thank.setBounds(80, 490, 330, 22);
		center.add(Thank);
		
		
		
		
		
		
		
		
		
		
		
		JLabel footer=new JLabel("########********########********########********########********########********########********########");
		footer.setBackground(new Color(50,60,250));
		footer.setBounds(0,520,450,10);
		center.add(footer);
		
		
		
		
		WindowFrame.setVisible(true);
		
	}

	public static void main(String[] args) {
		new Billgui();

	}

}
