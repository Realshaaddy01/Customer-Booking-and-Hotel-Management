package allgui.logingui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.UIManager;
import javax.swing.border.MatteBorder;

import allgui.admingui.AdminDashboard;
import allgui.customergui.CustomerDashboard;
import allgui.customergui.CustomerRegistration;
import allModels.CustomerModel1;
import allModels.CustomerModel2;
import allModels.CustomerLoginModel1;
import allModels.CustomerLoginModel2;
import DBControllers.Globalfile;
import allgui.staffgui.ReceptionDashboard;
import programRunner.MainApplicationStartup;

public class LoginPage {
	JFrame frame;
	JTextField txtUsername; 
	JPasswordField txtPassword;
	JButton LoginBtn,BackBtn;
	JCheckBox radioBtn;
	
	public LoginPage() {
		
		//------------Main Frame-------------------
		frame=new JFrame();
		frame.setTitle("Login");
		frame.setSize(1080,600);
		frame.setExtendedState(frame.MAXIMIZED_BOTH);
		frame.setIconImage(Toolkit.getDefaultToolkit().getImage(getClass().getResource("hotelicon1.png")));
		frame.setLayout(new BorderLayout());
		frame.setResizable(true);
		
//		-----North Panel-------
		JPanel Headpanel=new JPanel();
		Headpanel.setLayout(null);	
		Headpanel.setBackground(new Color(50,60,250));	
		Headpanel.setPreferredSize(new Dimension(80,45));
		frame.add(Headpanel, BorderLayout.NORTH);
		
		JLabel title =new JLabel("Login Page");
		title.setForeground(Color.white);
		title.setBounds(565,0,300,40);
		title.setFont(new Font("Verdana", Font.BOLD, 30));
		Headpanel.add(title);
		
		// ---------Center Panel-------
		JPanel center=new JPanel();
		center.setLayout(null);
		center.setBackground(new Color(222, 225, 236));
//		center.setPreferredSize(new Dimension(100,100));
		frame.add(center, BorderLayout.CENTER);
		
		
		//-------------Main Panel------------------------
		JPanel main=new JPanel();
		main.setBounds(300,80,800,450);
		main.setLayout(new BorderLayout());
		main.setBackground(new Color(255,255,255));
		center.add(main);
		
		//-------Main Panel North----------
		JPanel headlogin=new JPanel();
		headlogin.setLayout(null);
		headlogin.setBackground(new Color(255,255,255));
		headlogin.setPreferredSize(new Dimension(50,50));
		main.add(headlogin, BorderLayout.NORTH);
		
		
		JLabel name = new JLabel("Login");
		name.setBounds(365, 10, 300, 35);
		name.setForeground(new Color(25,25,112));
		name.setFont(new Font("Monospaced", Font.BOLD, 30));
		headlogin.add(name);
		
		JLabel image = new JLabel("");
		Image img = new ImageIcon(this.getClass().getResource("login.png")).getImage();
		image.setIcon(new ImageIcon(img));
		image.setPreferredSize(new Dimension(400, 500));
		main.add(image, BorderLayout.WEST);
		
		//-------------Main Panel Inside Main Panel-------------
		JPanel main1=new JPanel();
		main1.setLayout(null);
		main1.setBackground(new Color(255,255,255));
		main.add(main1, BorderLayout.CENTER);
		
		JLabel username = new JLabel("Username: ");
		username.setBounds(10, 90, 300, 35);
		username.setFont(new Font("Sans Sariff", Font.BOLD, 18));
		main1.add(username);
		
		txtUsername = new JTextField(15);
		txtUsername.setBorder(new MatteBorder(0, 0, 2, 0, new Color(70,130,180)));
		String html1 = "<html><p><font color=\"#800080\" " + "size=\"4\" face=\"Verdana\">Please enter your username!"
				+ "</font></p></html>";
		txtUsername.setToolTipText(html1);
		txtUsername.setBounds(130, 90, 250, 35);
		txtUsername.setFont(new Font("Verdana", Font.BOLD, 18));
		main1.add(txtUsername);
			
		
		JLabel password = new JLabel("Password: ");
		password.setBounds(10, 180, 300, 35);
		password.setFont(new Font("Sans Sariff", Font.BOLD, 18));
		main1.add(password);
		
		txtPassword = new JPasswordField(15);
		txtPassword.setBorder(new MatteBorder(0, 0, 2, 0, new Color(70,130,180)));
		String html2 = "<html><p><font color=\"#800080\" " + "size=\"4\" face=\"Verdana\">Please enter your password!"
				+ "</font></p></html>";
		txtPassword.setToolTipText(html2);
		txtPassword.setBounds(130, 180, 250, 35);
		txtPassword.setFont(new Font("Verdana", Font.BOLD, 18));
		main1.add(txtPassword);
		
		radioBtn = new JCheckBox("Show Password");
		radioBtn.setBackground(new Color(255,255,255));
		radioBtn.setFocusable(false);
		radioBtn.setToolTipText("Click here to show your password!");
		UIManager.put("ToolTip.background", Color.ORANGE);
		UIManager.put("ToolTip.foreground", Color.BLACK);
		UIManager.put("ToolTip.font", new Font("Arial", Font.PLAIN, 14));
		radioBtn.setBounds(130, 215, 150, 35);
		radioBtn.setFont(new Font("Verdana", Font.PLAIN, 12));
		radioBtn.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent evt) {
				// show password chars
				if (radioBtn.isSelected()) {
					txtPassword.setEchoChar((char) 0);
				}
				// hide password chars
				else {
					txtPassword.setEchoChar('*');
				}
			}
		});
		main1.add(radioBtn);
		
		
		LoginBtn = new JButton("Login");
		LoginBtn.setFocusable(false);
		LoginBtn.setBounds(80, 270, 110, 35);
		LoginBtn.setBackground(new Color(0,255,0));
		LoginBtn.setForeground(Color.WHITE);
		LoginBtn.setFont(new Font("Verdana", Font.BOLD, 15));
		main1.add(LoginBtn);
		LoginBtn.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent ae) {
				if (txtUsername.getText().trim().isEmpty() && String.valueOf(txtPassword.getPassword()).trim().isEmpty()) {
					JOptionPane.showMessageDialog(null, "Please enter username and password");
				}

				else if (ae.getSource() == LoginBtn) {
					
					CustomerModel2 user1 = new CustomerModel2();
					
					user1.setUsername(txtUsername.getText());
					user1.setPassword(String.valueOf(txtPassword.getPassword()));
					user1 = new CustomerLoginModel2().login(user1);
					
					Globalfile.registrationUser=user1;
					if (user1.getRegistration_ID() > 0) {
						ImageIcon i=new ImageIcon(getClass().getResource("hotelicon1.png"));
						JOptionPane.showMessageDialog(null, "Welcome "+user1.getName(),"Login Window",JOptionPane.WIDTH,i);
						
						if (user1.getRole().equals("Manager")) {
							new AdminDashboard();
							JOptionPane.showMessageDialog(null, "Welcome To Admin Dashboard","Login Window",JOptionPane.WIDTH,i);
							frame.dispose();
						} else if (user1.getRole().equals("Receptionist")) {
							JOptionPane.showMessageDialog(null, "Welcome To Staff Dashboard","Login Window",JOptionPane.WIDTH,i);
							new ReceptionDashboard();
							frame.dispose();
						}
						
						else if (user1.getRole().equals("Bar Staff")) {
							new CustomerRegistration();
							frame.dispose();
						}
						
						else if (user1.getRole().equals("Restaurant Staff")) {
							new CustomerRegistration();
							frame.dispose();
						}
						
						
						
					}
					
					else if (ae.getSource() == LoginBtn) {

					CustomerModel1 user = new CustomerModel1();
					user.setUsername(txtUsername.getText());
					user.setPassword(String.valueOf(txtPassword.getPassword()));
					user = new CustomerLoginModel1().login(user);
					
					
					Globalfile.currentUser=user;
					if (user.getCustomer_ID() > 0) {
						ImageIcon i2=new ImageIcon(getClass().getResource("hotel icon.png"));
						JOptionPane.showMessageDialog(null, "Welcome "+user.getName(),"Login Window",JOptionPane.WIDTH,i2);
						
						  if (user.getRole().equals("Individual")) {																					
							frame.dispose();
							JOptionPane.showMessageDialog(null, "Welcome To Customer Dashboard","Login Window",JOptionPane.WIDTH,i2);
							new CustomerDashboard();
							
						} else if (user.getRole().equals("Corp User")) {
							new CustomerDashboard();
							JOptionPane.showMessageDialog(null, "Welcome To Customer Dashboard","Login Window",JOptionPane.WIDTH,i2);
							frame.dispose();
						}
					} else {

						JOptionPane.showMessageDialog(null, "Incorrect Username and window");
						}
					}
				}
			}
		});
		
		BackBtn = new JButton("Back");
		BackBtn.setFocusable(false);
		BackBtn.setBounds(225, 270, 110, 35);
		BackBtn.setBackground(new Color(250,25,55));
		BackBtn.setForeground(Color.WHITE);
		BackBtn.setFont(new Font("Verdana", Font.BOLD, 15));
		BackBtn.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent ae) {

				if (ae.getSource() == BackBtn) {
					frame.dispose();
					new MainApplicationStartup();

				}
			}

		});
		main1.add(BackBtn);
		
		
		
		
		frame.setVisible(true);
		
		
	}

	public static void main(String[] args) {
		new LoginPage();

	}

}
