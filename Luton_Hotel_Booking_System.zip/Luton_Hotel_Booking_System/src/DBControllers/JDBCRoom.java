package DBControllers;

import java.sql.Connection;


import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import allModels.RoomModel1;


public class JDBCRoom extends DatabaseConnection {
	
	public boolean update (RoomModel1 room) {
		Connection conn;
		PreparedStatement pstat;
		String sql="UPDATE rooms SET type=?,rate=?, rooms_status=? WHERE Room_ID=?";
		boolean result=false;
		
		try {
			conn=connect();
			pstat=conn.prepareStatement(sql);
			pstat.setString(1, room.getType());
			pstat.setDouble(2, room.getRate());
			pstat.setString(3, room.getStatus());
			pstat.setInt(4, room.getId());
			
			pstat.executeUpdate();
			pstat.close();
			conn.close();
			result=true;
		}
		catch (Exception ex) {
			System.out.println("Error"+ex.getMessage());
		}
		return result;
		
	}
	
	public RoomModel1 search (int rid) {
		
		Connection conn;
		PreparedStatement pstat;
		ResultSet rs;
		String sql="SELECT * FROM rooms WHERE Room_ID=?";
		RoomModel1 room=new RoomModel1();
		
		try {
			conn=connect();
			pstat=conn.prepareStatement(sql);
			pstat.setInt(1, rid);
			rs=pstat.executeQuery();
			while(rs.next())
			{
				
				room.setId(rs.getInt("Room_ID"));
				room.setType(rs.getString("type"));
				room.setRate(rs.getDouble("rate"));
				room.setStatus(rs.getString("rooms_status"));
				
			}
			
			
		}
		catch (Exception ex) {
			
			System.out.println("Error"+ex.getMessage());
		}
		return room;
		
	}
	
	public boolean insert (RoomModel1 room) {
		Connection conn;
		PreparedStatement pstat;
		boolean result=false;
		String sql="INSERT INTO rooms VALUES (?,?,?,?)";
		
		try {
			
			//insert
			conn=connect();
			pstat=conn.prepareStatement(sql);
			pstat.setInt(1, room.getId());
			pstat.setString(2, room.getType());
			pstat.setDouble(3, room.getRate());
			pstat.setString(4,room.getStatus());
			
			pstat.executeUpdate(); //insert, delete, update
			
			pstat.close();
			conn.close();
			result=true;
			
		}
		catch (Exception ex) {
			
			System.out.println("Error"+ex.getMessage());
		}
		
		
		
		
		return result;
		
		
		
		
	}
	public ArrayList getAvailableRooms() {
		ResultSet rs;
		String sql="SELECT  * FROM rooms WHERE rooms_status='Available'";
		ArrayList rooms=new ArrayList();
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");

			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/database_luton_hotel", "root", "");
			
			PreparedStatement pstat=conn.prepareStatement(sql);
			rs=pstat.executeQuery();
			while(rs.next()) {
				RoomModel1 room=new RoomModel1(rs.getInt("Room_ID"),
						rs.getString("type"),
						rs.getInt("rate"),
						rs.getString("rooms_status"));
				rooms.add(room);
			}
			
			
			
			
			
		}
		catch(Exception ex) {
			System.out.println("Error"+ex.getMessage());
		}
		
		
		
		
		
		
		return rooms;
	}
	
	
public ArrayList select_all() {
		
		String sql="SELECT  * FROM rooms";
		ArrayList room=new ArrayList();

		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");

		
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/database_luton_hotel", "root", "");
			PreparedStatement pstat=conn.prepareStatement(sql);
			
			ResultSet rs=pstat.executeQuery();
		
			while(rs.next()) {
				
				RoomModel1 tmp= new RoomModel1(
		    rs.getInt("Room_ID"),
			rs.getString("type"),
			rs.getDouble("rate"),
			rs.getString("rooms_status"));				
			room.add(tmp);
			}
			
			conn.close();
			
		} catch (Exception ex) {

			System.out.println("Error" + ex.getMessage());
		}
		return room;
	}
  
public boolean update1 (RoomModel1 room) {
	
	
	PreparedStatement pstat;
	boolean result1=false;
	String sql="UPDATE rooms SET rooms_status=? WHERE Room_ID=?";
	
	try {
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/database_luton_hotel", "root","");			
		pstat=conn.prepareStatement(sql);			
		pstat.setString(1, room.getStatus());
		pstat.setInt(2, room.getId());
		
		pstat.executeUpdate();			
		pstat.close();
		conn.close();
		result1=true;			
	}
	
	
	
	
	catch (Exception ex){
		System.out.println("Error"+ex.getMessage());
		
		
	}

	return result1;
	
}

}
