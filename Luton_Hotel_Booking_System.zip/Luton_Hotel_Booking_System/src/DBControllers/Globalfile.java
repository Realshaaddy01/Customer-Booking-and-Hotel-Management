package DBControllers;

import allModels.BillingModel3;
import allModels.CustomerModel1;
import allModels.CustomerModel2;
import allModels.CustomerModel3;

public class Globalfile {
	public static final String ROOM_TYPES[]= {"Single","Double","Deluxe","Twin"};	
	public static final double ROOM_PRICE[]= {1000,2000,3000,3000};
	public static final String ROOM_STATUS[]= {"Available","Booked"};
	
	public static CustomerModel1 currentUser;
	
	
	public static CustomerModel3 admin;
	
	
	public static BillingModel3 currentBilling;
	
	
	public static CustomerModel2 registrationUser;
	
	
	
}
