package DBControllers;

import java.sql.Connection;

import java.sql.DriverManager;

public class DatabaseConnection {
	final static String Driver="com.mysql.cj.jdbc.Driver";		
	final static String DBNAME="database_luton_hotel";
	final static String HOST="localhost";
	final static int PORT =3306;
	final static String URL="jdbc:mysql://"+HOST+":"+PORT+"/"+DBNAME;
	final static String USER ="root";
	final static String PASSWORD="";
	
	
	public static Connection connect() {
		Connection conn = null;
		
		try {
			Class.forName(Driver);   //loading driver
			conn=DriverManager.getConnection(URL, USER, PASSWORD);
		
		}
		
		catch (Exception ex) {
			System.out.println("Error"+ex.getMessage());
		}
		return conn;
		
	}
	

}
